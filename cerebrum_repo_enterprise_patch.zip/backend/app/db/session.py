"""Session management for SQLAlchemy sessions.

This module provides a reusable dependency for FastAPI routes to
interact with the database. It delegates to the central engine
creation defined in `core.database`.
"""

from ..core.database import SessionLocal


def get_session():
    """Yield a session for dependency injection in FastAPI handlers."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
