import React, { useState } from 'react';
import axios from '../lib/api';
import { toast } from 'react-hot-toast';

interface Clash {
  element_a: string;
  element_b: string;
  severity: string;
}

export default function VDC() {
  const [files, setFiles] = useState<FileList | null>(null);
  const [clashes, setClashes] = useState<Clash[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleDetectClashes = async () => {
    if (!files || files.length < 2) {
      toast.error('Please select at least two IFC files');
      return;
    }
    setIsLoading(true);
    const formData = new FormData();
    Array.from(files).forEach((file) => {
      formData.append('files', file);
    });
    try {
      const res = await axios.post('/vdc/clash-detection', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setClashes(res.data.clashes);
      toast.success('Clash detection completed');
    } catch (err) {
      toast.error('Failed to detect clashes');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFederate = async () => {
    if (!files || files.length === 0) {
      toast.error('Please select IFC files');
      return;
    }
    setIsLoading(true);
    const formData = new FormData();
    Array.from(files).forEach((file) => {
      formData.append('files', file);
    });
    try {
      await axios.post('/vdc/federate', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      toast.success('Federation request sent');
    } catch (err) {
      toast.error('Failed to federate models');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Virtual Design & Construction (VDC)</h2>
      <p className="mb-4">Upload IFC files to detect clashes or federate models.</p>
      <input
        type="file"
        multiple
        accept=".ifc"
        onChange={(e) => setFiles(e.target.files)}
        className="mb-2"
      />
      <div className="flex space-x-2 mb-4">
        <button
          onClick={handleDetectClashes}
          disabled={isLoading}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded disabled:opacity-50"
        >
          {isLoading ? 'Processing...' : 'Detect Clashes'}
        </button>
        <button
          onClick={handleFederate}
          disabled={isLoading}
          className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded disabled:opacity-50"
        >
          {isLoading ? 'Processing...' : 'Federate Models'}
        </button>
      </div>
      {clashes && (
        <div className="mt-4 bg-white dark:bg-gray-800 p-4 rounded shadow">
          <h3 className="font-semibold mb-2">Clash Results</h3>
          {clashes.length === 0 ? (
            <p>No clashes found.</p>
          ) : (
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100 dark:bg-gray-700">
                  <th className="px-2 py-1 text-left">Element A</th>
                  <th className="px-2 py-1 text-left">Element B</th>
                  <th className="px-2 py-1 text-left">Severity</th>
                </tr>
              </thead>
              <tbody>
                {clashes.map((c, idx) => (
                  <tr key={idx} className="border-t">
                    <td className="px-2 py-1">{c.element_a}</td>
                    <td className="px-2 py-1">{c.element_b}</td>
                    <td className="px-2 py-1">{c.severity}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  );
}