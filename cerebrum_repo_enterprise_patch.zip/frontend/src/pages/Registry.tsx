import React from 'react';

export default function Registry() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Registry</h2>
      <p>This service catalog will display available capabilities and integrations.</p>
    </div>
  );
}