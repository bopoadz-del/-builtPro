"""Aggregate API routers for the FastAPI application."""

from fastapi import APIRouter

from .auth import router as auth_router
from .admin import router as admin_router
from .registry import router as registry_router
from .drive import router as drive_router
from .economics import router as economics_router
from .keys import router as keys_router
from .vdc import router as vdc_router
from .monitoring import router as monitoring_router
from .analytics import router as analytics_router
from .tenants import router as tenants_router
from .bids import router as bids_router
from .rfi import router as rfi_router
from .integrations import router as integrations_router


api_router = APIRouter(prefix="/api/v1")

api_router.include_router(auth_router, prefix="/auth", tags=["auth"])
api_router.include_router(admin_router, prefix="/admin", tags=["admin"])
api_router.include_router(registry_router, prefix="/registry", tags=["registry"])
api_router.include_router(drive_router, prefix="/drive", tags=["drive"])
api_router.include_router(economics_router, prefix="/economics", tags=["economics"])
api_router.include_router(keys_router, prefix="/keys", tags=["api_keys"])
api_router.include_router(vdc_router, prefix="/vdc", tags=["vdc"])
api_router.include_router(tenants_router, prefix="/tenants", tags=["tenants"])
api_router.include_router(bids_router, prefix="/bids", tags=["bids"])
api_router.include_router(rfi_router, prefix="/rfis", tags=["rfis"])
api_router.include_router(integrations_router, prefix="/integrations", tags=["integrations"])

# Monitoring and analytics
api_router.include_router(monitoring_router, prefix="/monitoring", tags=["monitoring"])
api_router.include_router(analytics_router, prefix="/analytics", tags=["analytics"])
