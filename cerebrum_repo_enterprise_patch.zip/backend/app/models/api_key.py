"""
API Key model for scoped access.

API keys allow external integrations to call the Cerebrum API with
granular permissions. Each key belongs to a user and can be scoped
to one or more actions (e.g. ``read:projects``, ``write:documents``).
Keys can be revoked at any time. The actual key string should be
generated using a secure random source and stored hashed.
"""

import uuid
from sqlalchemy import Column, DateTime, String, Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from .base import Base


class ApiKey(Base):
    __tablename__ = "api_key"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), nullable=True)

    user_id = Column(UUID(as_uuid=True), ForeignKey("user.id", ondelete="CASCADE"), nullable=False)
    key = Column(String, unique=True, nullable=False)
    scopes = Column(String, nullable=False)  # comma‑separated scopes
    revoked = Column(Boolean, nullable=False, server_default="false")

    user = relationship("User", backref="api_keys")