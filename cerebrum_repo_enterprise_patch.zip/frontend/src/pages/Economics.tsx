import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from '../lib/api';
import { toast } from 'react-hot-toast';

interface Budget {
  id: string;
  project_id: string;
  total_amount: number;
  currency: string;
  contingency_percentage?: number | null;
  is_final: boolean;
}

export default function Economics() {
  const queryClient = useQueryClient();
  const { data: budgets, isLoading } = useQuery<Budget[]>({
    queryKey: ['budgets'],
    queryFn: async () => {
      const res = await axios.get('/economics/budgets');
      return res.data;
    },
  });

  // State for new budget form
  const [projectId, setProjectId] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [contingency, setContingency] = useState('');

  const createBudgetMutation = useMutation({
    mutationFn: async () => {
      const body = {
        project_id: projectId,
        total_amount: parseFloat(amount),
        currency,
        contingency_percentage: contingency ? parseFloat(contingency) : null,
      };
      const res = await axios.post('/economics/budgets', body);
      return res.data;
    },
    onSuccess: () => {
      toast.success('Budget created');
      queryClient.invalidateQueries({ queryKey: ['budgets'] });
      setProjectId('');
      setAmount('');
      setContingency('');
    },
    onError: () => {
      toast.error('Failed to create budget');
    },
  });

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Economics</h2>
      <p className="mb-4">View and manage project budgets.</p>
      <div className="mb-8 p-4 bg-white dark:bg-gray-800 rounded shadow">
          <h3 className="font-semibold mb-2">Create Budget</h3>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 mb-4">
            <input
              type="text"
              placeholder="Project ID (UUID)"
              value={projectId}
              onChange={(e) => setProjectId(e.target.value)}
              className="border p-2 rounded"
            />
            <input
              type="number"
              placeholder="Total Amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="border p-2 rounded"
            />
            <input
              type="text"
              placeholder="Currency"
              value={currency}
              onChange={(e) => setCurrency(e.target.value.toUpperCase())}
              className="border p-2 rounded"
              maxLength={3}
            />
            <input
              type="number"
              placeholder="Contingency %"
              value={contingency}
              onChange={(e) => setContingency(e.target.value)}
              className="border p-2 rounded"
              min="0"
              max="100"
              step="0.01"
            />
          </div>
          <button
            onClick={() => createBudgetMutation.mutate()}
            disabled={createBudgetMutation.isLoading || !projectId || !amount}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded disabled:opacity-50"
          >
            {createBudgetMutation.isLoading ? 'Creating...' : 'Create'}
          </button>
      </div>
      <div className="bg-white dark:bg-gray-800 rounded shadow p-4">
        <h3 className="font-semibold mb-2">Budgets</h3>
        {isLoading ? (
          <p>Loading...</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100 dark:bg-gray-700">
                  <th className="px-2 py-1 text-left">ID</th>
                  <th className="px-2 py-1 text-left">Project</th>
                  <th className="px-2 py-1 text-left">Total</th>
                  <th className="px-2 py-1 text-left">Currency</th>
                  <th className="px-2 py-1 text-left">Contingency %</th>
                  <th className="px-2 py-1 text-left">Final</th>
                </tr>
              </thead>
              <tbody>
                {budgets && budgets.length > 0 ? (
                  budgets.map((b) => (
                    <tr key={b.id} className="border-t">
                      <td className="px-2 py-1 truncate" title={b.id}>{b.id}</td>
                      <td className="px-2 py-1 truncate" title={b.project_id}>{b.project_id}</td>
                      <td className="px-2 py-1">${b.total_amount.toFixed(2)}</td>
                      <td className="px-2 py-1">{b.currency}</td>
                      <td className="px-2 py-1">{b.contingency_percentage ?? '-'}</td>
                      <td className="px-2 py-1">{b.is_final ? 'Yes' : 'No'}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="px-2 py-2 text-center">No budgets found.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}