"""System status utilities.

This module provides a function to compute simple status information
about the running application. For production use you might collect
CPU/memory/disk metrics using psutil or expose a health check via
Prometheus exporters. Here we return the uptime and a static status
message as a placeholder.
"""

from datetime import datetime, timezone
from .metrics import metrics


def get_status() -> dict[str, str | float]:
    """Return basic status information including uptime in seconds
    and a timestamp. This function can be expanded to include more
    metrics such as CPU or memory usage when necessary.
    """
    now = datetime.now(timezone.utc)
    start_time = metrics._counters.get("start_time_seconds", 0.0)
    uptime = now.timestamp() - start_time
    return {
        "status": "ok",
        "timestamp": now.isoformat(),
        "uptime_seconds": uptime,
    }