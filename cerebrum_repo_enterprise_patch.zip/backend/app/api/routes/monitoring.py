"""Monitoring and observability API routes.

These endpoints expose basic metrics and status information for the
application. In a production environment these would be scraped by
Prometheus or consumed by health probes.
"""

from fastapi import APIRouter, Response

from ...monitoring import metrics as metrics_mod
from ...monitoring import status as status_mod


router = APIRouter(prefix="/monitoring", tags=["monitoring"])


@router.get("/metrics", response_class=Response, status_code=200)
def get_metrics() -> Response:
    """Return metrics in plain text Prometheus exposition format."""
    content = metrics_mod.render_metrics()
    return Response(content=content, media_type="text/plain; version=0.0.4")


@router.get("/status", response_model=dict)
def get_status() -> dict[str, str | float]:
    """Return basic system status including uptime."""
    return status_mod.get_status()