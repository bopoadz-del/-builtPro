"""Database utilities including a transactional context manager."""

from contextlib import contextmanager
from sqlalchemy.orm import Session


@contextmanager
def transactional(session: Session):
    """Provide a transactional scope around a series of operations.

    If an exception is raised within the block, the transaction is rolled
    back. Support for nested transactions is provided via savepoints.

    Example::

        with transactional(db):
            db.add(obj)
            ...

    """
    nested = session.transaction.is_active
    if nested:
        # We're already in a transaction; use a savepoint
        savepoint = session.begin_nested()
        try:
            yield
            savepoint.commit()
        except Exception:
            savepoint.rollback()
            raise
    else:
        try:
            with session.begin():
                yield
        except Exception:
            session.rollback()
            raise