import React from 'react';
import { useSettings } from '../store/useSettings';

/**
 * Toggle switch to enable or disable the Smart Context system.
 * When enabled, certain pages (e.g. chat) display a badge and may
 * change behaviour. State is persisted in the zustand store.
 */
export default function SmartContextToggle() {
  const { smartContextEnabled, toggleSmartContext } = useSettings();
  return (
    <div className="flex items-center space-x-2">
      <span className="text-sm">Smart Context</span>
      <label className="inline-flex relative items-center cursor-pointer">
        <input
          type="checkbox"
          className="sr-only peer"
          checked={smartContextEnabled}
          onChange={toggleSmartContext}
        />
        <div
          className="w-9 h-5 bg-gray-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-green-600"
        />
      </label>
    </div>
  );
}