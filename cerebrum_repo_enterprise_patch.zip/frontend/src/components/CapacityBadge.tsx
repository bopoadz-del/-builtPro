import React from 'react';
import { useSettings } from '../store/useSettings';

/**
 * Displays the current capacity as a percentage with coloured badge.
 * The colour changes based on thresholds: green (>50%), yellow (20–50%), red (<20%).
 */
export default function CapacityBadge() {
  const { capacity } = useSettings();
  const getColor = () => {
    if (capacity > 50) return 'bg-green-100 text-green-800';
    if (capacity > 20) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };
  return (
    <span
      className={`px-2 py-1 rounded text-xs font-medium inline-flex items-center ${getColor()}`}
    >
      Capacity: {capacity}%
    </span>
  );
}