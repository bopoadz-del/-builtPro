"""
Procore integration stubs.

Provides placeholder functions for connecting to Procore, syncing
projects, drawings, RFIs and other entities. In later phases this
module should handle OAuth2 authentication, rate limiting and error
handling when calling Procore's API.
"""

from typing import List, Dict


def get_oauth_url(state: str) -> str:
    """Return the URL for initiating Procore OAuth2.

    Args:
        state: CSRF state string.
    Returns:
        A placeholder authorization URL.
    """
    return f"https://login.procore.com/oauth/authorize?state={state}"


def exchange_code_for_token(code: str) -> Dict[str, str]:
    """Exchange an authorization code for an access token.

    Returns static token data for demonstration.
    """
    return {"access_token": "procore-access", "refresh_token": "procore-refresh"}


def list_projects(access_token: str) -> List[Dict[str, str]]:
    """List Procore projects available to the user.

    Returns dummy data.
    """
    return [
        {"id": "pc-project-1", "name": "Main Hospital"},
        {"id": "pc-project-2", "name": "Office Tower"},
    ]