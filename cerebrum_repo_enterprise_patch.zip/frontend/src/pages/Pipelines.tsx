import React from 'react';

export default function Pipelines() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Pipelines</h2>
      <p>The pipeline builder canvas and job status list will appear here.</p>
    </div>
  );
}