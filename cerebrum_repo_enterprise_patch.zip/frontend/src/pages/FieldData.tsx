import React from 'react';

export default function FieldData() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Field Data</h2>
      <p>Offline forms for daily reports and punch lists will be implemented.</p>
    </div>
  );
}