import React from 'react';

export default function Learning() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Learning</h2>
      <p>Model registry and experiment tracking UI will be built here.</p>
    </div>
  );
}