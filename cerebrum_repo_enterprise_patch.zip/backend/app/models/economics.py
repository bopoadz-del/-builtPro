"""
Economics models for budgeting and change order management.

These SQLAlchemy models represent the basic financial constructs
outlined in the master specification. Additional fields and models
can be added as the system evolves (e.g., labor cost engine,
equipment rentals, tax calculations).
"""

import uuid
from sqlalchemy import Column, DateTime, Numeric, String, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from .base import Base


class Budget(Base):
    __tablename__ = "budget"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), nullable=True)

    # In a multi‑tenant system, budgets would be tied to a project or tenant
    # via foreign keys. For demonstration purposes, these relationships
    # are omitted.
    project_id = Column(UUID(as_uuid=True), nullable=False)

    total_amount = Column(Numeric(precision=12, scale=2), nullable=False)
    currency = Column(String(3), nullable=False)
    contingency_percentage = Column(Numeric(precision=5, scale=2), nullable=True)

    # Flags for draft or final budgets
    is_final = Column(Boolean, nullable=False, server_default="false")


class ChangeOrder(Base):
    __tablename__ = "change_order"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), nullable=True)
    project_id = Column(UUID(as_uuid=True), nullable=False)
    description = Column(String, nullable=False)
    amount = Column(Numeric(precision=12, scale=2), nullable=False)
    approved = Column(Boolean, nullable=False, server_default="false")

    # Additional fields such as who requested and approved the change,
    # before/after quantities and revision tracking can be added later.