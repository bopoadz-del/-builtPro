import React from 'react';

export default function BIMViewer() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">BIM Viewer</h2>
      <p>A 3D model viewer (React Three Fiber) will be integrated here.</p>
    </div>
  );
}