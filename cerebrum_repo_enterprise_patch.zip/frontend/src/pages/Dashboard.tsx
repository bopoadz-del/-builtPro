import React from 'react';

// Dashboard placeholder. This page will show overview cards and recent
// activity in later iterations.
export default function Dashboard() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Dashboard</h2>
      <p>Welcome to Cerebrum. This dashboard will display project summaries and quick actions.</p>
    </div>
  );
}
