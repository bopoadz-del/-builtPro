import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from '../lib/api';
import { toast } from 'react-hot-toast';

interface PortfolioSummary {
  total_projects: number;
  active_projects: number;
  completed_projects: number;
  total_budget: number;
  budget_spent: number;
  cost_overrun: number;
  average_delay_days: number;
}

export default function Analytics() {
  const queryClient = useQueryClient();
  // Fetch the portfolio summary
  const { data: summary, isLoading } = useQuery<PortfolioSummary>({
    queryKey: ['portfolio-summary'],
    queryFn: async () => {
      const res = await axios.get('/analytics/portfolio');
      return res.data;
    },
    staleTime: 60_000, // 1 minute
  });

  // Mutation to trigger ETL job
  const etlMutation = useMutation({
    mutationFn: async () => {
      const res = await axios.post('/analytics/etl');
      return res.data;
    },
    onSuccess: (data) => {
      toast.success(`ETL started at ${data.started_at || ''}`);
      // Refetch the summary after ETL
      queryClient.invalidateQueries({ queryKey: ['portfolio-summary'] });
    },
    onError: () => {
      toast.error('Failed to start ETL job');
    },
  });

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Analytics Dashboard</h2>
      <p className="mb-6">View portfolio metrics and run ETL jobs.</p>
      <div className="mb-6 bg-white dark:bg-gray-800 rounded shadow p-4">
        <h3 className="font-semibold mb-2">Portfolio Summary</h3>
        {isLoading || !summary ? (
          <p>Loading...</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
            <div className="p-2 bg-gray-50 dark:bg-gray-700 rounded">
              <strong>Total Projects:</strong> {summary.total_projects}
            </div>
            <div className="p-2 bg-gray-50 dark:bg-gray-700 rounded">
              <strong>Active Projects:</strong> {summary.active_projects}
            </div>
            <div className="p-2 bg-gray-50 dark:bg-gray-700 rounded">
              <strong>Completed Projects:</strong> {summary.completed_projects}
            </div>
            <div className="p-2 bg-gray-50 dark:bg-gray-700 rounded">
              <strong>Total Budget:</strong> ${summary.total_budget.toLocaleString()}
            </div>
            <div className="p-2 bg-gray-50 dark:bg-gray-700 rounded">
              <strong>Budget Spent:</strong> ${summary.budget_spent.toLocaleString()}
            </div>
            <div className="p-2 bg-gray-50 dark:bg-gray-700 rounded">
              <strong>Cost Overrun:</strong> {(summary.cost_overrun * 100).toFixed(1)}%
            </div>
            <div className="p-2 bg-gray-50 dark:bg-gray-700 rounded">
              <strong>Avg Delay (days):</strong> {summary.average_delay_days}
            </div>
          </div>
        )}
      </div>
      <div className="bg-white dark:bg-gray-800 rounded shadow p-4">
        <h3 className="font-semibold mb-2">Run ETL</h3>
        <p className="mb-2">Trigger the ETL process to refresh analytics. This operation may take a few minutes.</p>
        <button
          onClick={() => etlMutation.mutate()}
          disabled={etlMutation.isLoading}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded disabled:opacity-50"
        >
          {etlMutation.isLoading ? 'Starting...' : 'Start ETL'}
        </button>
      </div>
    </div>
  );
}