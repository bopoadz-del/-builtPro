import React from 'react';
import SmartContextToggle from '../SmartContextToggle';
import CapacityBadge from '../CapacityBadge';
import { useSettings } from '../../store/useSettings';


// Top navigation bar placeholder. You can add tenant selector,
// notifications and user menu here.
interface TopBarProps {
  onMenuClick?: () => void;
}

export default function TopBar({ onMenuClick }: TopBarProps) {
  const { darkMode, toggleDarkMode } = useSettings();
  return (
    <header className="h-16 flex items-center justify-between px-4 border-b border-gray-200 bg-white dark:bg-gray-800 dark:border-gray-700">
      <div className="flex items-center space-x-2">
        {/* Mobile menu button */}
        <button
          onClick={onMenuClick}
          className="lg:hidden p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700"
          aria-label="Open sidebar"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={1.5}
            stroke="currentColor"
            className="w-6 h-6"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M3.75 5.25h16.5m-16.5 6h16.5m-16.5 6h16.5"
            />
          </svg>
        </button>
        <h1 className="text-lg font-semibold hidden sm:block">Cerebrum</h1>
      </div>
      <div className="flex items-center space-x-4">
        <CapacityBadge />
        <SmartContextToggle />
        <button
          onClick={toggleDarkMode}
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
          aria-label="Toggle dark mode"
        >
          {darkMode ? (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="w-5 h-5"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 3v1.5m0 15V21m9-9h-1.5m-15 0H3m15.364-5.364l-1.06 1.06m-10.607 10.607l-1.06 1.06m0-12.727l1.06 1.06m12.727 12.727l1.06 1.06M16.364 7.636A5.25 5.25 0 0112.75 18a5.25 5.25 0 01-4.614-10.364 5.005 5.005 0 005.114 5.114A5.25 5.25 0 0116.364 7.636z"
              />
            </svg>
          ) : (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="w-5 h-5"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 3v1.5m0 15V21m9-9h-1.5m-15 0H3m15.364-5.364l-1.06 1.06m-10.607 10.607l-1.06 1.06m0-12.727l1.06 1.06m12.727 12.727l1.06 1.06M9.172 9.172a4 4 0 105.656 5.656 4 4 0 00-5.656-5.656z"
              />
            </svg>
          )}
        </button>
      </div>
    </header>
  );
}
