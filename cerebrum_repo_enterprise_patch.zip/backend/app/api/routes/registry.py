"""Endpoints for managing capability registry entries."""

from typing import List
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ...core.database import get_db
from ...models.registry import Capability, CapabilityStatus


class CapabilityCreate(BaseModel):
    name: str
    version: str
    code_artifact_url: str | None = None
    dependencies: List[str] | None = None
    author: str | None = None


router = APIRouter()


@router.post("/capabilities")
def create_capability(payload: CapabilityCreate, db: Session = Depends(get_db)):
    """Create a new capability entry in draft status."""
    existing = db.query(Capability).filter(Capability.name == payload.name).first()
    if existing:
        raise HTTPException(status_code=400, detail="Capability with this name already exists")
    cap = Capability(
        name=payload.name,
        version=payload.version,
        status=CapabilityStatus.DRAFT,
        code_artifact_url=payload.code_artifact_url,
        dependencies=payload.dependencies or [],
        author=payload.author,
    )
    db.add(cap)
    db.commit()
    db.refresh(cap)
    return cap


@router.patch("/capabilities/{cap_id}/validate")
def validate_capability(cap_id: str, db: Session = Depends(get_db)):
    """Promote a capability to validated status."""
    cap = db.query(Capability).filter(Capability.id == cap_id).first()
    if not cap:
        raise HTTPException(status_code=404, detail="Capability not found")
    cap.status = CapabilityStatus.VALIDATED
    db.commit()
    db.refresh(cap)
    return cap


@router.patch("/capabilities/{cap_id}/deprecate")
def deprecate_capability(cap_id: str, db: Session = Depends(get_db)):
    """Mark a capability as deprecated."""
    cap = db.query(Capability).filter(Capability.id == cap_id).first()
    if not cap:
        raise HTTPException(status_code=404, detail="Capability not found")
    cap.status = CapabilityStatus.DEPRECATED
    db.commit()
    db.refresh(cap)
    return cap


@router.get("/capabilities")
def list_capabilities(db: Session = Depends(get_db)):
    """List all capabilities."""
    caps = db.query(Capability).all()
    return caps
