import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import axios from '../lib/api';

interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
}

export default function Documents() {
  const [token, setToken] = useState('');
  const [enabled, setEnabled] = useState(false);

  const { data: files, isLoading, error } = useQuery<DriveFile[]>({
    queryKey: ['driveFiles', token],
    queryFn: async () => {
      const res = await axios.get('/drive/files', { params: { access_token: token } });
      return res.data;
    },
    enabled: enabled && !!token,
  });

  const listFiles = () => {
    setEnabled(true);
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Documents</h2>
      <p className="mb-4">Browse files from Google Drive (stub implementation).</p>
      <div className="mb-4 flex flex-col sm:flex-row items-center gap-2">
        <input
          type="text"
          placeholder="Access Token"
          value={token}
          onChange={(e) => setToken(e.target.value)}
          className="border p-2 rounded flex-1"
        />
        <button
          onClick={listFiles}
          disabled={!token}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded disabled:opacity-50"
        >
          List Files
        </button>
      </div>
      {isLoading && <p>Loading...</p>}
      {error && <p className="text-red-600">Failed to load files.</p>}
      {files && (
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="bg-gray-100 dark:bg-gray-700">
                <th className="px-2 py-1 text-left">ID</th>
                <th className="px-2 py-1 text-left">Name</th>
                <th className="px-2 py-1 text-left">MIME Type</th>
              </tr>
            </thead>
            <tbody>
              {files.map((file) => (
                <tr key={file.id} className="border-t">
                  <td className="px-2 py-1 truncate" title={file.id}>{file.id}</td>
                  <td className="px-2 py-1">{file.name}</td>
                  <td className="px-2 py-1">{file.mimeType}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}