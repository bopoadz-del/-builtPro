import { create } from 'zustand';

interface SettingsState {
  darkMode: boolean;
  smartContextEnabled: boolean;
  capacity: number;
  toggleDarkMode: () => void;
  toggleSmartContext: () => void;
  setCapacity: (capacity: number) => void;
}

const getInitialDarkMode = (): boolean => {
  if (typeof window === 'undefined') return false;
  try {
    const stored = localStorage.getItem('darkMode');
    return stored ? JSON.parse(stored) : false;
  } catch {
    return false;
  }
};

export const useSettings = create<SettingsState>((set) => ({
  darkMode: getInitialDarkMode(),
  smartContextEnabled: false,
  capacity: 0,
  toggleDarkMode: () =>
    set((state) => {
      const next = !state.darkMode;
      if (typeof window !== 'undefined') {
        const root = document.documentElement;
        if (next) {
          root.classList.add('dark');
        } else {
          root.classList.remove('dark');
        }
        try {
          localStorage.setItem('darkMode', JSON.stringify(next));
        } catch {
          // ignore
        }
      }
      return { darkMode: next };
    }),
  toggleSmartContext: () =>
    set((state) => {
      const next = !state.smartContextEnabled;
      return { smartContextEnabled: next };
    }),
  setCapacity: (capacity: number) => set(() => ({ capacity })),
}));