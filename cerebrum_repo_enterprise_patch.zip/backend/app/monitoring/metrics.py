"""Simple metrics collection for Cerebrum.

This module provides a lightweight mechanism to collect runtime metrics
such as total requests and error counts. It exposes a function to
render the metrics in a Prometheus‑style text format. In a real
production system you would likely use a dedicated metrics library
such as ``prometheus_client`` or integrate with a full observability
stack. This implementation serves as a placeholder for Phase 6
instrumentation.
"""

import threading
from time import time


class Metrics:
    """Thread‑safe metrics collector."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._counters: dict[str, float] = {
            "requests_total": 0.0,
            "errors_total": 0.0,
            "start_time_seconds": time(),
        }

    def inc(self, name: str, amount: float = 1.0) -> None:
        """Increment a named counter by ``amount``. If the counter does
        not exist it will be created with the given amount.
        """
        with self._lock:
            self._counters[name] = self._counters.get(name, 0.0) + amount

    def get_metrics(self) -> str:
        """Return all metrics in Prometheus exposition format."""
        with self._lock:
            lines = []
            for key, value in self._counters.items():
                lines.append(f"# HELP {key} Automatically generated metric")
                lines.append(f"# TYPE {key} counter")
                lines.append(f"{key} {value}")
            return "\n".join(lines) + "\n"


# Global metrics instance
metrics = Metrics()


def record_request(success: bool) -> None:
    """Record a request. Increment ``requests_total`` and
    ``errors_total`` if not successful.
    """
    metrics.inc("requests_total")
    if not success:
        metrics.inc("errors_total")


def render_metrics() -> str:
    """Return all metrics in text format."""
    return metrics.get_metrics()