"""Authentication endpoints for users.

This module exposes endpoints for login, registration and token
refresh. Password hashing uses bcrypt via passlib. JWT tokens are
issued via the configured secret key. For simplicity this example
stores refresh tokens in memory; a production system would use
Redis or another persistent store.
"""

from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from jose import jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from ...core.config import get_settings
from ...models.user import User, UserRole
from ...core.database import get_db


router = APIRouter()

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# In‑memory refresh token blacklist; use Redis in production
refresh_blacklist: set[str] = set()


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    settings = get_settings()
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=settings.jwt_access_token_expires_minutes))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.jwt_secret_key, algorithm="HS256")
    return encoded_jwt


def create_refresh_token(subject: str) -> str:
    settings = get_settings()
    expire = datetime.utcnow() + timedelta(days=settings.jwt_refresh_token_expires_days)
    data = {"sub": subject, "exp": expire, "type": "refresh"}
    return jwt.encode(data, settings.jwt_secret_key, algorithm="HS256")


@router.post("/register")
def register(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """Register a new user with an email and password.

    In this simple implementation, users are created on the fly with the
    USER role. Duplicate emails will raise an error.
    """
    existing = db.query(User).filter(User.email == form_data.username).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    user = User(
        email=form_data.username,
        hashed_password=get_password_hash(form_data.password),
        role=UserRole.USER,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"message": "User registered", "user_id": str(user.id)}


@router.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """Authenticate a user and return access and refresh tokens."""
    user = db.query(User).filter(User.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    if not user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")
    access_token = create_access_token({"sub": str(user.id)})
    refresh_token = create_refresh_token(str(user.id))
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
    }


@router.post("/refresh")
def refresh_token(token: str, db: Session = Depends(get_db)):
    """Exchange a valid refresh token for a new access token.

    Refresh tokens are one‑time use; a used token is added to the
    blacklist and cannot be used again. In production, use Redis for
    storing used tokens with expiry.
    """
    settings = get_settings()
    try:
        payload = jwt.decode(token, settings.jwt_secret_key, algorithms=["HS256"])
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid refresh token")
    if payload.get("type") != "refresh":
        raise HTTPException(status_code=400, detail="Not a refresh token")
    jti = token  # using full token as unique identifier for simplicity
    if jti in refresh_blacklist:
        raise HTTPException(status_code=400, detail="Refresh token already used")
    refresh_blacklist.add(jti)
    user_id = payload.get("sub")
    new_access_token = create_access_token({"sub": user_id})
    new_refresh_token = create_refresh_token(user_id)
    return {
        "access_token": new_access_token,
        "refresh_token": new_refresh_token,
        "token_type": "bearer",
    }
