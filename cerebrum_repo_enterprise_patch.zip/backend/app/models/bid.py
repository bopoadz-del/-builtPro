"""
Bid model for subcontractor bids.

Represents a bid submitted by a subcontractor for a trade package. The
bid includes a list of line items and a total amount. The status
tracks the review process.
"""

import uuid
from sqlalchemy import Column, String, Numeric, Enum, JSON
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .base import Base


class BidStatus(str, Enum):  # type: ignore[misc]
    submitted = "submitted"
    under_review = "under_review"
    approved = "approved"
    rejected = "rejected"


class Bid(Base):
    __tablename__ = "bid"

    # Foreign keys to project and tenant if needed; using UUIDs for now
    project_id = Column(UUID(as_uuid=True), nullable=False)
    tenant_id = Column(UUID(as_uuid=True), nullable=False)

    subcontractor_name = Column(String, nullable=False)
    items = Column(JSON, nullable=True)  # list of line items
    total_amount = Column(Numeric(precision=12, scale=2), nullable=False)
    status = Column(Enum(BidStatus), nullable=False, default=BidStatus.submitted)