"""
Circuit breaker utilities.

This module defines a simple circuit breaker using the pybreaker
package. If pybreaker is not installed, a no‑op breaker is used.
Use this to wrap calls to external services to prevent cascading
failures. See Phase 4 specification for details.
"""

try:
    import pybreaker  # type: ignore
except ImportError:  # pragma: no cover
    pybreaker = None


def get_circuit_breaker(name: str = "cerebrum"):
    """Return a circuit breaker instance.

    If pybreaker is unavailable, return a dummy object with a no‑op
    call method.
    """
    if pybreaker:
        return pybreaker.CircuitBreaker(fail_max=3, reset_timeout=60, name=name)
    else:
        class DummyBreaker:
            def call(self, func, *args, **kwargs):
                return func(*args, **kwargs)
        return DummyBreaker()