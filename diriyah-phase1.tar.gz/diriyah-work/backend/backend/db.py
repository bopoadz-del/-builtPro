import logging
import os
from pathlib import Path

from sqlalchemy import create_engine, text
from sqlalchemy.orm import declarative_base, sessionmaker

logger = logging.getLogger(__name__)

RENDER_REQUIRED_MESSAGE = (
    "Render requires Postgres. Set DATABASE_URL to your Render Postgres Internal URL on BOTH web and worker services."
)


def _is_render_environment() -> bool:
    return any(
        os.getenv(key)
        for key in ("RENDER", "RENDER_SERVICE_ID", "RENDER_SERVICE_NAME")
    )


def _normalize_database_url(raw_url: str) -> str:
    if raw_url.startswith("postgres://"):
        return raw_url.replace("postgres://", "postgresql://", 1)
    return raw_url


def _sqlite_url_for_path(path: str) -> str:
    abs_path = Path(path).expanduser().resolve()
    return f"sqlite:////{abs_path}"


def _resolve_database_url() -> tuple[str, bool, str | None]:
    raw_database_url = os.getenv("DATABASE_URL")
    if _is_render_environment():
        if not raw_database_url:
            raise RuntimeError(RENDER_REQUIRED_MESSAGE)
        normalized_url = _normalize_database_url(raw_database_url)
        if normalized_url.startswith("sqlite:"):
            raise RuntimeError(RENDER_REQUIRED_MESSAGE)
        return normalized_url, True, None
    if raw_database_url:
        return _normalize_database_url(raw_database_url), True, None

    sqlite_path = os.getenv("SQLITE_PATH")
    if not sqlite_path:
        default_path = Path("/var/data/app.db") if Path("/var/data").exists() else Path("./app.db")
        sqlite_path = str(default_path)
    return _sqlite_url_for_path(sqlite_path), False, sqlite_path


DATABASE_URL, DATABASE_URL_SET, SQLITE_PATH = _resolve_database_url()


def _connect_args_for_url(url: str) -> dict:
    if url.startswith("sqlite"):
        return {"check_same_thread": False}
    if url.startswith("postgresql") or url.startswith("postgres"):
        return {"connect_timeout": 5}
    return {}


connect_args = _connect_args_for_url(DATABASE_URL)
engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

logger.info(
    "Database configured: dialect=%s database_url_set=%s sqlite_path=%s",
    engine.url.get_backend_name(),
    DATABASE_URL_SET,
    SQLITE_PATH,
)


def _import_models() -> None:
    """Import all SQLAlchemy models so metadata is populated."""

    from backend.backend import models as _core_models  # noqa: F401
    from backend.backend.pdp import models as _pdp_models  # noqa: F401
    from backend.events import models as _event_models  # noqa: F401
    from backend.hydration import models as _hydration_models  # noqa: F401
    from backend.learning import models as _learning_models  # noqa: F401
    from backend.ops import models as _ops_models  # noqa: F401
    from backend.regression import models as _regression_models  # noqa: F401
    from backend.runtime import models as _runtime_models  # noqa: F401


_import_models()


def _apply_postgres_schema_hotfixes(connection) -> None:
    """Apply schema migrations for existing Postgres databases."""
    # Make rate_limits.user_id nullable (was NOT NULL, now nullable for anonymous requests)
    try:
        connection.execute(
            text("ALTER TABLE rate_limits ALTER COLUMN user_id DROP NOT NULL")
        )
        logger.info("init_db: Applied hotfix - rate_limits.user_id now nullable")
    except Exception as exc:
        if "does not exist" not in str(exc).lower():
            logger.debug("init_db: rate_limits hotfix skipped: %s", exc)

    # Make pdp_audit_logs.user_id nullable (for anonymous audit logging)
    try:
        connection.execute(
            text("ALTER TABLE pdp_audit_logs ALTER COLUMN user_id DROP NOT NULL")
        )
        logger.info("init_db: Applied hotfix - pdp_audit_logs.user_id now nullable")
    except Exception as exc:
        if "does not exist" not in str(exc).lower():
            logger.debug("init_db: pdp_audit_logs hotfix skipped: %s", exc)

    # Add google_drive_public to hydration SourceType enum (Render/Postgres hotfix)
    try:
        connection.execute(
            text(
                """
                DO $$
                BEGIN
                  IF EXISTS (SELECT 1 FROM pg_type WHERE typname = 'sourcetype') THEN
                    IF NOT EXISTS (
                      SELECT 1
                      FROM pg_type t
                      JOIN pg_enum e ON t.oid = e.enumtypid
                      WHERE t.typname = 'sourcetype' AND e.enumlabel = 'google_drive_public'
                    ) THEN
                      ALTER TYPE sourcetype ADD VALUE 'google_drive_public';
                    END IF;
                  END IF;
                END $$;
                """
            )
        )
        logger.info("init_db: Applied hotfix - sourcetype includes google_drive_public")
    except Exception as exc:
        logger.debug("init_db: sourcetype hotfix skipped: %s", exc)


def init_db() -> None:
    """Ensure all tables exist for the current metadata."""

    _import_models()
    table_names = list(Base.metadata.tables.keys())
    logger.info("init_db: %d tables registered in metadata: %s", len(table_names), table_names)
    Base.metadata.create_all(bind=engine)
    logger.info("init_db: create_all completed")

    # Apply schema hotfixes for existing Postgres databases
    if DATABASE_URL.startswith("postgresql"):
        with engine.connect() as conn:
            _apply_postgres_schema_hotfixes(conn)
            conn.commit()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
