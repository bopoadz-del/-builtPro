import React from 'react';

export default function Tasks() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Tasks</h2>
      <p>This page will monitor task queues and worker status.</p>
    </div>
  );
}