import React from 'react';

export default function Audit() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Audit Logs</h2>
      <p>A table of audit log entries with filters will be implemented.</p>
    </div>
  );
}