import React from 'react';
import { NavLink } from 'react-router-dom';

interface SidebarProps {
  open: boolean;
  onClose: () => void;
}

/**
 * Responsive sidebar navigation. On large screens it is always visible;
 * on small screens it slides out from the left when `open` is true.
 */
export default function Sidebar({ open, onClose }: SidebarProps) {
  const navItems = [
    { to: '/', label: 'Dashboard', end: true },
    { to: '/registry', label: 'Registry' },
    { to: '/learning', label: 'Learning' },
    { to: '/sandbox', label: 'Sandbox' },
    { to: '/audit', label: 'Audit' },
    { to: '/pipelines', label: 'Pipelines' },
    { to: '/settings', label: 'API Management' },
    { to: '/tasks', label: 'Tasks' },
    { to: '/bim-viewer', label: 'BIM Viewer' },
    { to: '/action-items', label: 'Action Items' },
    { to: '/documents', label: 'Documents' },
    { to: '/chat', label: 'Chat' },
    { to: '/admin', label: 'Admin Panel' },
    { to: '/economics', label: 'Economics' },
    { to: '/ml-tinker', label: 'ML Tinker' },
    { to: '/edge-devices', label: 'Edge Devices' },
    { to: '/field-data', label: 'Field Data' },
    { to: '/vdc', label: 'VDC' },
    { to: '/quality', label: 'Quality' },
    { to: '/subcontractor', label: 'Subcontractor' },
    { to: '/analytics', label: 'Analytics' },
  ];

  const navItemClass = ({ isActive }: { isActive: boolean }) =>
    `block px-4 py-2 rounded text-sm ${
      isActive
        ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-200 font-medium'
        : 'hover:bg-gray-100 dark:hover:bg-gray-700'
    }`;

  return (
    <>
      {/* Overlay for mobile */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-black bg-opacity-25 lg:hidden"
          onClick={onClose}
        />
      )}
      <aside
        className={`
          fixed lg:static z-50 inset-y-0 left-0 transform transition-transform duration-200
          w-60 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700
          ${open ? 'translate-x-0' : '-translate-x-full'}
          lg:translate-x-0 lg:block
        `}
      >
        <nav className="mt-4 space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end as any}
              className={navItemClass}
              onClick={onClose}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
      </aside>
    </>
  );
}
