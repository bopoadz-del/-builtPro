"""Declarative base and mixins for SQLAlchemy models."""

import uuid
from datetime import datetime

from sqlalchemy import Column, DateTime, Boolean, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import as_declarative, declared_attr


@as_declarative()
class Base:
    """Base class for all models.

    This class defines a primary key column using UUIDs and
    automatically generates table names based on the class name.
    """

    id: uuid.UUID

    @declared_attr
    def __tablename__(cls) -> str:
        return cls.__name__.lower()

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, unique=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), nullable=True)


class SoftDeleteMixin:
    """Mixin providing soft deletion via a nullable timestamp column.

    Records are never removed from the database; instead the
    `deleted_at` timestamp is set. To filter for active records, use
    `deleted_at.is_(None)` in your queries.
    """

    deleted_at = Column(DateTime(timezone=True), nullable=True)

    @property
    def is_deleted(self) -> bool:
        return self.deleted_at is not None

    @classmethod
    def active(cls, session):
        """Return a query filtered to only include non‑deleted records."""
        return session.query(cls).filter(cls.deleted_at.is_(None))
