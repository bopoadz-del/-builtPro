"""add tenant fields

Revision ID: 0002_add_tenant_fields
Revises: 0001_initial
Create Date: 2026-02-13

This migration adds additional fields to the tenant table to support
enterprise onboarding features such as custom subdomains, branding,
subscription plans and trial periods.
"""

from alembic import op
import sqlalchemy as sa

revision = '0002_add_tenant_fields'
down_revision = '0001_initial'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Add new columns to the tenant table
    op.add_column('tenant', sa.Column('subdomain', sa.String(), nullable=False))
    op.add_column('tenant', sa.Column('logo_url', sa.String(), nullable=True))
    op.add_column('tenant', sa.Column('plan', sa.String(), nullable=False, server_default='free'))
    op.add_column('tenant', sa.Column('trial_ends_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('tenant', sa.Column('is_active', sa.Boolean(), nullable=False, server_default=sa.true()))
    # Create unique index on subdomain
    op.create_index('uq_tenant_subdomain', 'tenant', ['subdomain'], unique=True)


def downgrade() -> None:
    op.drop_index('uq_tenant_subdomain', table_name='tenant')
    op.drop_column('tenant', 'is_active')
    op.drop_column('tenant', 'trial_ends_at')
    op.drop_column('tenant', 'plan')
    op.drop_column('tenant', 'logo_url')
    op.drop_column('tenant', 'subdomain')