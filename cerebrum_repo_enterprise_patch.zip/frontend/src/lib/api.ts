import axios from 'axios';

// Axios instance configured with base URL and interceptors for authentication
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api/v1',
});

// Add auth header if access token is present
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token');
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Global response error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      // Handle unauthorized responses globally (e.g., redirect to login)
      localStorage.removeItem('access_token');
      // window.location.href = '/login';
    }
    return Promise.reject(error);
  },
);

export default api;