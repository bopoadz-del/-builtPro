import React from 'react';

export default function Sandbox() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Sandbox</h2>
      <p>A Jupyter‑like notebook interface will go here.</p>
    </div>
  );
}