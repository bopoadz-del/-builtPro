"""
Column Level Encryption utilities.

Provides a custom SQLAlchemy type ``EncryptedType`` that encrypts
sensitive data at rest using symmetric AES‑256 encryption. This
implementation uses the Fernet primitive from the cryptography
package. In a real production system, key management and rotation
should be handled by a secrets management service.
"""

import base64
import os
from cryptography.fernet import Fernet
from sqlalchemy.types import TypeDecorator, String


class EncryptedType(TypeDecorator):
    """SQLAlchemy type that transparently encrypts and decrypts values."""

    impl = String
    cache_ok = True

    def __init__(self, key: bytes | None = None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Generate a key if none provided
        self.key = key or base64.urlsafe_b64encode(os.urandom(32))
        self.fernet = Fernet(self.key)

    def process_bind_param(self, value: str | None, dialect):
        if value is None:
            return value
        if not isinstance(value, bytes):
            value_bytes = value.encode('utf-8')
        else:
            value_bytes = value
        token = self.fernet.encrypt(value_bytes)
        return token.decode('utf-8')

    def process_result_value(self, value: str | None, dialect):
        if value is None:
            return value
        token_bytes = value.encode('utf-8')
        try:
            plaintext = self.fernet.decrypt(token_bytes)
        except Exception:
            # If decryption fails, return the raw value to avoid data loss
            return value
        return plaintext.decode('utf-8')