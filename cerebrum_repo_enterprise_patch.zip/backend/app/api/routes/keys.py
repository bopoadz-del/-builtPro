"""
API Key management endpoints.

This router provides endpoints for users to create, list and revoke
API keys. Keys include scopes that grant permissions for specific
operations. For demonstration purposes, authentication and scope
validation are omitted. In production, ensure only authorized
administrators can create or revoke keys, and never return the
plaintext key after creation.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field

from ...db.session import SessionLocal
from ...models.api_key import ApiKey
from ...security.api_keys import generate_api_key, hash_api_key, parse_scopes

router = APIRouter(prefix="/keys", tags=["api_keys"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class ApiKeyCreate(BaseModel):
    user_id: str
    scopes: str = Field(..., description="Comma‑separated list of scopes (e.g. read:projects,write:documents)")


class ApiKeyRead(BaseModel):
    id: str
    user_id: str
    scopes: str
    revoked: bool

    class Config:
        orm_mode = True


class ApiKeyWithSecret(ApiKeyRead):
    secret: str


@router.get("/", response_model=list[ApiKeyRead])
def list_api_keys(db: Session = Depends(get_db)) -> list[ApiKeyRead]:
    keys = db.query(ApiKey).all()
    return keys


@router.post("/", response_model=ApiKeyWithSecret)
def create_api_key(api_key_in: ApiKeyCreate, db: Session = Depends(get_db)) -> ApiKeyWithSecret:
    # Generate a new key and hash it
    raw_key = generate_api_key(32)
    hashed_key = hash_api_key(raw_key)
    # Validate scopes (in a real implementation, check against allowed scopes)
    if not parse_scopes(api_key_in.scopes):
        raise HTTPException(status_code=400, detail="Invalid scopes")
    new_key = ApiKey(
        user_id=api_key_in.user_id,
        key=hashed_key,
        scopes=api_key_in.scopes,
        revoked=False,
    )
    db.add(new_key)
    db.commit()
    db.refresh(new_key)
    # Return the raw key only on creation
    return ApiKeyWithSecret(id=str(new_key.id), user_id=str(new_key.user_id), scopes=new_key.scopes, revoked=new_key.revoked, secret=raw_key)


@router.delete("/{key_id}", response_model=ApiKeyRead)
def revoke_api_key(key_id: str, db: Session = Depends(get_db)) -> ApiKeyRead:
    key_obj = db.query(ApiKey).filter(ApiKey.id == key_id).first()
    if not key_obj:
        raise HTTPException(status_code=404, detail="API key not found")
    key_obj.revoked = True
    db.commit()
    db.refresh(key_obj)
    return key_obj