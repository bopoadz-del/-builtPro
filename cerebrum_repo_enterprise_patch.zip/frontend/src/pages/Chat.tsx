import React from 'react';
import { useSettings } from '../store/useSettings';

export default function Chat() {
  const { smartContextEnabled } = useSettings();
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Chat</h2>
      {smartContextEnabled && (
        <span className="bg-green-100 text-green-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded">
          Smart Context: ON
        </span>
      )}
      <p>AI chat interface will be implemented here.</p>
    </div>
  );
}