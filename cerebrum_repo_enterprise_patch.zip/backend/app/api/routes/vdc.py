"""
VDC API endpoints.

This router exposes endpoints for virtual design and construction
operations such as uploading multiple IFC models for federation and
clash detection, and generating reports. The actual geometry
processing is deferred to the VDC pipeline module and will be
implemented in later phases.
"""

from fastapi import APIRouter, UploadFile, File, HTTPException
from typing import List
from pydantic import BaseModel

from ...pipelines import ifc_geometry
from ...pipelines import vdc

router = APIRouter(prefix="/vdc", tags=["vdc"])


class Clash(BaseModel):
    element_a: str
    element_b: str
    severity: str


class ClashResponse(BaseModel):
    clashes: List[Clash]


@router.post("/clash-detection", response_model=ClashResponse)
async def clash_detection(files: List[UploadFile] = File(...)) -> ClashResponse:
    """Detect clashes between multiple uploaded IFC files.

    Args:
        files: A list of uploaded IFC files.

    Returns:
        A list of detected clashes. Currently returns an empty list.
    """
    models = []
    for f in files:
        # Save to a temporary file and parse
        try:
            contents = await f.read()
            tmp_path = f"/tmp/{f.filename}"
            with open(tmp_path, "wb") as tmp:
                tmp.write(contents)
            model = ifc_geometry.parse_ifc(tmp_path)
            models.append(model)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to process {f.filename}: {e}")
    clashes = vdc.detect_clashes(models)
    return ClashResponse(clashes=[Clash(**c) for c in clashes])  # type: ignore[list-item]


class FederatedModelResponse(BaseModel):
    message: str


@router.post("/federate", response_model=FederatedModelResponse)
async def federate_models(files: List[UploadFile] = File(...)) -> FederatedModelResponse:
    """Federate multiple IFC models into one.

    Args:
        files: IFC files to federate.

    Returns:
        A message indicating success. Real implementation would return
        a file path or model ID.
    """
    models = []
    for f in files:
        try:
            contents = await f.read()
            tmp_path = f"/tmp/{f.filename}"
            with open(tmp_path, "wb") as tmp:
                tmp.write(contents)
            model = ifc_geometry.parse_ifc(tmp_path)
            models.append(model)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to process {f.filename}: {e}")
    vdc.federate_models(models)
    return FederatedModelResponse(message="Models federated (stub)")