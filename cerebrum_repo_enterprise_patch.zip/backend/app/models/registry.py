"""Capability registry model for self‑coding infrastructure."""

import enum
from typing import List, Optional

from sqlalchemy import Column, Enum, String, JSON, ForeignKey
from sqlalchemy.dialects.postgresql import UUID

from .base import Base


class CapabilityStatus(str, enum.Enum):
    DRAFT = "draft"
    VALIDATED = "validated"
    DEPRECATED = "deprecated"


class Capability(Base):
    """Represents a registered capability that can be promoted through a lifecycle."""

    name = Column(String, unique=True, nullable=False)
    version = Column(String, nullable=False)
    status = Column(Enum(CapabilityStatus), default=CapabilityStatus.DRAFT)
    code_artifact_url = Column(String, nullable=True)
    dependencies = Column(JSON, nullable=True, default=list)
    author = Column(String, nullable=True)
