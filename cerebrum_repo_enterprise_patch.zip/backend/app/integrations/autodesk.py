"""
Autodesk Construction Cloud integration stubs.

Defines placeholders for OAuth2 flow and listing BIM 360 projects.
Further integrations would handle models, files and issue sync.
"""

from typing import List, Dict


def get_oauth_url(state: str) -> str:
    return f"https://developer.api.autodesk.com/auth/v2/authorize?state={state}"


def exchange_code_for_token(code: str) -> Dict[str, str]:
    return {"access_token": "autodesk-access", "refresh_token": "autodesk-refresh"}


def list_projects(access_token: str) -> List[Dict[str, str]]:
    return [
        {"id": "adsk-project-1", "name": "Residential Complex"},
        {"id": "adsk-project-2", "name": "Data Center"},
    ]