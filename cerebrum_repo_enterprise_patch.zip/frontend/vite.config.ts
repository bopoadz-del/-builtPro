import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Vite configuration for the Cerebrum frontend. Uses React plugin and
// defines a simple build without further customization. You can add
// aliases and optimize chunks here as the project grows.
export default defineConfig({
  plugins: [react()],
  build: {
    chunkSizeWarningLimit: 600,
  },
});
