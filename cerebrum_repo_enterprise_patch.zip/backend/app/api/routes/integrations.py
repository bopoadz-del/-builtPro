"""
Integration hub API.

Consolidates endpoints for various external integrations (Procore,
Autodesk, PlanGrid, etc.). These endpoints currently return stubbed
data and URLs. Real implementations will handle OAuth flows and
call external APIs.
"""

from fastapi import APIRouter, Query
from pydantic import BaseModel

from ...integrations import procore, autodesk


router = APIRouter(prefix="/integrations", tags=["integrations"])


class OAuthURL(BaseModel):
    url: str


@router.get("/procore/oauth", response_model=OAuthURL)
def get_procore_oauth(state: str = Query(...)) -> OAuthURL:
    return OAuthURL(url=procore.get_oauth_url(state))


@router.get("/autodesk/oauth", response_model=OAuthURL)
def get_autodesk_oauth(state: str = Query(...)) -> OAuthURL:
    return OAuthURL(url=autodesk.get_oauth_url(state))


class Project(BaseModel):
    id: str
    name: str


@router.get("/procore/projects", response_model=list[Project])
def list_procore_projects(access_token: str = Query(...)) -> list[Project]:
    projects = procore.list_projects(access_token)
    return [Project(**p) for p in projects]  # type: ignore[list-item]


@router.get("/autodesk/projects", response_model=list[Project])
def list_autodesk_projects(access_token: str = Query(...)) -> list[Project]:
    projects = autodesk.list_projects(access_token)
    return [Project(**p) for p in projects]  # type: ignore[list-item]