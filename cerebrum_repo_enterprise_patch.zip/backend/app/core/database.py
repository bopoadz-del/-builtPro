"""Database utilities for SQLAlchemy engine and session management."""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from .config import get_settings


def get_engine():
    """Create a SQLAlchemy engine using configured settings.

    Connection pooling parameters are tuned for a web application. The
    engine uses a pre‑ping to validate connections on checkout and
    recycles connections periodically to avoid stale sessions.
    """
    settings = get_settings()
    return create_engine(
        settings.database_url,
        pool_size=settings.pool_size,
        max_overflow=settings.max_overflow,
        pool_recycle=settings.pool_recycle,
        pool_pre_ping=True,
    )


# Create a configured "Session" class and a scoped session factory
engine = get_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    """Provide a database session dependency for FastAPI routes.

    The session is closed after the request to release it back into the pool.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
