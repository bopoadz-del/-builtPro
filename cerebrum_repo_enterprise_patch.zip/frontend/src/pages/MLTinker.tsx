import React from 'react';

export default function MLTinker() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">ML Tinker</h2>
      <p>AutoML interface and model comparison tools will be developed.</p>
    </div>
  );
}