"""Seed the database with initial data for development/testing."""

from sqlalchemy.orm import Session

from ..core.database import engine
from ..models.user import User, UserRole
from ..models.registry import Capability
from ..api.routes.auth import get_password_hash


def seed(db: Session) -> None:
    # Create an admin user
    admin_email = "admin@cerebrum.ai"
    if not db.query(User).filter(User.email == admin_email).first():
        admin = User(
            email=admin_email,
            hashed_password=get_password_hash("admin"),
            role=UserRole.ADMIN,
        )
        db.add(admin)
        print("Created admin user")

    # Example capability
    if not db.query(Capability).filter(Capability.name == "ifc_parser").first():
        cap = Capability(
            name="ifc_parser",
            version="1.0.0",
            status="draft",
        )
        db.add(cap)
        print("Created example capability")

    db.commit()


def main():
    from ..core.database import SessionLocal
    db = SessionLocal()
    try:
        seed(db)
    finally:
        db.close()


if __name__ == "__main__":
    main()
