import React from 'react';

export default function PageLoader() {
  return (
    <div className="flex justify-center items-center h-full w-full">
      <span className="animate-spin h-8 w-8 border-4 border-blue-600 border-t-transparent rounded-full" />
    </div>
  );
}