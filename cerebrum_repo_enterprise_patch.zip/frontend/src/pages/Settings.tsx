import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from '../lib/api';
import { toast } from 'react-hot-toast';

interface ApiKey {
  id: string;
  user_id: string;
  scopes: string;
  revoked: boolean;
}

interface ApiKeyWithSecret extends ApiKey {
  secret: string;
}

export default function Settings() {
  const queryClient = useQueryClient();
  const { data: keys, isLoading } = useQuery<ApiKey[]>({
    queryKey: ['apiKeys'],
    queryFn: async () => {
      const res = await axios.get('/keys');
      return res.data;
    },
  });
  const [userId, setUserId] = useState('');
  const [scopes, setScopes] = useState('read:projects');
  const [newKey, setNewKey] = useState<ApiKeyWithSecret | null>(null);

  const createKeyMutation = useMutation({
    mutationFn: async () => {
      const res = await axios.post('/keys', { user_id: userId, scopes });
      return res.data as ApiKeyWithSecret;
    },
    onSuccess: (data) => {
      setNewKey(data);
      toast.success('API key created');
      queryClient.invalidateQueries({ queryKey: ['apiKeys'] });
    },
    onError: () => {
      toast.error('Failed to create API key');
    },
  });

  const revokeKeyMutation = useMutation({
    mutationFn: async (id: string) => {
      await axios.delete(`/keys/${id}`);
    },
    onSuccess: () => {
      toast.success('API key revoked');
      queryClient.invalidateQueries({ queryKey: ['apiKeys'] });
    },
    onError: () => {
      toast.error('Failed to revoke API key');
    },
  });

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">API Management</h2>
      <div className="mb-8 p-4 bg-white dark:bg-gray-800 rounded shadow">
        <h3 className="font-semibold mb-2">Create API Key</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-4">
          <input
            type="text"
            placeholder="User ID (UUID)"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            className="border p-2 rounded"
          />
          <input
            type="text"
            placeholder="Scopes (comma separated)"
            value={scopes}
            onChange={(e) => setScopes(e.target.value)}
            className="border p-2 rounded"
          />
        </div>
        <button
          onClick={() => createKeyMutation.mutate()}
          disabled={createKeyMutation.isLoading || !userId || !scopes}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded disabled:opacity-50"
        >
          {createKeyMutation.isLoading ? 'Creating...' : 'Create Key'}
        </button>
        {newKey && (
          <div className="mt-4 p-2 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded">
            <p className="text-sm font-medium">New API Key:</p>
            <code className="break-all">{newKey.secret}</code>
            <p className="text-xs mt-1">Make sure to copy this key now; it will not be shown again.</p>
          </div>
        )}
      </div>
      <div className="bg-white dark:bg-gray-800 rounded shadow p-4">
        <h3 className="font-semibold mb-2">Existing API Keys</h3>
        {isLoading ? (
          <p>Loading...</p>
        ) : (
          <table className="min-w-full text-sm">
            <thead>
              <tr className="bg-gray-100 dark:bg-gray-700">
                <th className="px-2 py-1 text-left">ID</th>
                <th className="px-2 py-1 text-left">User</th>
                <th className="px-2 py-1 text-left">Scopes</th>
                <th className="px-2 py-1 text-left">Revoked</th>
                <th className="px-2 py-1 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {keys && keys.length > 0 ? (
                keys.map((key) => (
                  <tr key={key.id} className="border-t">
                    <td className="px-2 py-1 truncate" title={key.id}>{key.id}</td>
                    <td className="px-2 py-1 truncate" title={key.user_id}>{key.user_id}</td>
                    <td className="px-2 py-1">{key.scopes}</td>
                    <td className="px-2 py-1">{key.revoked ? 'Yes' : 'No'}</td>
                    <td className="px-2 py-1 space-x-1">
                      {!key.revoked && (
                        <button
                          onClick={() => revokeKeyMutation.mutate(key.id)}
                          className="bg-red-600 hover:bg-red-700 text-white px-2 py-1 rounded text-xs"
                        >
                          Revoke
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-2 py-2 text-center">No API keys found.</td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}