"""
Celery task configuration and example tasks.

This module defines a Celery application instance and example tasks
for both fast and slow operations. In production you would
configure separate queues for high‑priority API tasks, long‑running
IFC processing, and scheduled jobs. Celery workers are defined in
docker-compose.yml.
"""

import os
from celery import Celery

from .core.config import get_settings

settings = get_settings()

# Use Redis as both broker and result backend. In production these
# would be separate and configured for high availability (e.g. Redis
# Sentinel).
celery_app = Celery(
    "cerebrum",
    broker=os.getenv("CELERY_BROKER_URL", settings.redis_queue_url),
    backend=os.getenv("CELERY_BACKEND_URL", settings.redis_queue_url),
)

# Example Celery task
@celery_app.task(name="tasks.add")
def add(x: int, y: int) -> int:
    return x + y