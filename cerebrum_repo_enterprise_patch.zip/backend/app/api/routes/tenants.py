"""
Tenant management API endpoints.

Provides endpoints for tenant onboarding and management. Tenants
represent customers in a multi‑tenant deployment. When creating a
tenant, an administrator can specify a unique subdomain and plan.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
import uuid

from ...db.session import SessionLocal
from ...models.tenant import Tenant

router = APIRouter(prefix="/tenants", tags=["tenants"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class TenantCreate(BaseModel):
    name: str = Field(..., example="Acme Construction")
    subdomain: str = Field(..., example="acme")
    plan: str = Field("free", example="pro")
    logo_url: str | None = Field(None, example="https://example.com/logo.png")


class TenantRead(BaseModel):
    id: uuid.UUID
    name: str
    subdomain: str
    plan: str
    logo_url: str | None
    is_active: bool
    trial_ends_at: str | None

    class Config:
        orm_mode = True


@router.get("/", response_model=list[TenantRead])
def list_tenants(db: Session = Depends(get_db)) -> list[TenantRead]:
    tenants = db.query(Tenant).all()
    return tenants


@router.post("/", response_model=TenantRead, status_code=status.HTTP_201_CREATED)
def create_tenant(tenant_in: TenantCreate, db: Session = Depends(get_db)) -> TenantRead:
    # Check for existing subdomain or name
    if db.query(Tenant).filter((Tenant.subdomain == tenant_in.subdomain) | (Tenant.name == tenant_in.name)).first():
        raise HTTPException(status_code=400, detail="Tenant with this name or subdomain already exists")
    tenant = Tenant(
        name=tenant_in.name,
        subdomain=tenant_in.subdomain,
        logo_url=tenant_in.logo_url,
        plan=tenant_in.plan,
    )
    db.add(tenant)
    db.commit()
    db.refresh(tenant)
    return tenant


@router.get("/{tenant_id}", response_model=TenantRead)
def get_tenant(tenant_id: uuid.UUID, db: Session = Depends(get_db)) -> TenantRead:
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    return tenant


@router.patch("/{tenant_id}", response_model=TenantRead)
def update_tenant(tenant_id: uuid.UUID, tenant_in: TenantCreate, db: Session = Depends(get_db)) -> TenantRead:
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    # Update fields
    if tenant_in.name:
        tenant.name = tenant_in.name
    if tenant_in.subdomain:
        # Ensure unique subdomain
        if db.query(Tenant).filter(Tenant.subdomain == tenant_in.subdomain, Tenant.id != tenant_id).first():
            raise HTTPException(status_code=400, detail="Subdomain already in use")
        tenant.subdomain = tenant_in.subdomain
    tenant.plan = tenant_in.plan or tenant.plan
    tenant.logo_url = tenant_in.logo_url
    db.commit()
    db.refresh(tenant)
    return tenant