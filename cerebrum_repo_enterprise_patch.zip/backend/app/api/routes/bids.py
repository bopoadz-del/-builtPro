"""
Bid submission and management API.

Endpoints for subcontractors to submit bids and for project managers
to review them. Bids belong to a project and tenant.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
import uuid

from ...db.session import SessionLocal
from ...models.bid import Bid, BidStatus

router = APIRouter(prefix="/bids", tags=["bids"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class BidCreate(BaseModel):
    project_id: uuid.UUID
    tenant_id: uuid.UUID
    subcontractor_name: str
    items: dict | None = None
    total_amount: float = Field(..., ge=0)


class BidRead(BaseModel):
    id: uuid.UUID
    project_id: uuid.UUID
    tenant_id: uuid.UUID
    subcontractor_name: str
    items: dict | None
    total_amount: float
    status: BidStatus

    class Config:
        orm_mode = True


@router.get("/", response_model=list[BidRead])
def list_bids(db: Session = Depends(get_db)) -> list[BidRead]:
    bids = db.query(Bid).all()
    return bids


@router.post("/", response_model=BidRead, status_code=status.HTTP_201_CREATED)
def submit_bid(bid_in: BidCreate, db: Session = Depends(get_db)) -> BidRead:
    bid = Bid(
        project_id=bid_in.project_id,
        tenant_id=bid_in.tenant_id,
        subcontractor_name=bid_in.subcontractor_name,
        items=bid_in.items,
        total_amount=bid_in.total_amount,
        status=BidStatus.submitted,
    )
    db.add(bid)
    db.commit()
    db.refresh(bid)
    return bid


@router.get("/{bid_id}", response_model=BidRead)
def get_bid(bid_id: uuid.UUID, db: Session = Depends(get_db)) -> BidRead:
    bid = db.query(Bid).filter(Bid.id == bid_id).first()
    if not bid:
        raise HTTPException(status_code=404, detail="Bid not found")
    return bid


class BidUpdateStatus(BaseModel):
    status: BidStatus


@router.patch("/{bid_id}", response_model=BidRead)
def update_bid_status(bid_id: uuid.UUID, status_in: BidUpdateStatus, db: Session = Depends(get_db)) -> BidRead:
    bid = db.query(Bid).filter(Bid.id == bid_id).first()
    if not bid:
        raise HTTPException(status_code=404, detail="Bid not found")
    bid.status = status_in.status
    db.commit()
    db.refresh(bid)
    return bid