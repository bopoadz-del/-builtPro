"""Application configuration using Pydantic settings.

This module defines a BaseSettings class that reads from environment
variables and provides strongly‑typed access throughout the application.

The settings cover database connectivity, Redis, JWT secrets and
application behaviour toggles. Validation happens on startup so the
application fails fast when misconfigured.
"""

from functools import lru_cache
from typing import Optional

from pydantic import BaseSettings, Field, validator


class Settings(BaseSettings):
    """Global application settings with strict validation.

    Environment variables are automatically loaded and cast to the
    appropriate types. See the documentation for each field for
    descriptions. Additional variables may be added as the system
    evolves, for example to support external integrations in later
    phases.
    """

    # Database configuration
    database_url: str = Field(..., env="DATABASE_URL", description="PostgreSQL connection string")
    pool_size: int = Field(20, env="DB_POOL_SIZE", description="SQLAlchemy pool size")
    max_overflow: int = Field(0, env="DB_MAX_OVERFLOW", description="SQLAlchemy max overflow")
    pool_recycle: int = Field(3600, env="DB_POOL_RECYCLE", description="Seconds before recycling idle connections")

    # JWT configuration
    jwt_secret_key: str = Field(..., env="JWT_SECRET_KEY", description="Secret used to sign JWT tokens")
    jwt_access_token_expires_minutes: int = Field(15, env="JWT_ACCESS_EXPIRY", description="Access token lifetime in minutes")
    jwt_refresh_token_expires_days: int = Field(7, env="JWT_REFRESH_EXPIRY", description="Refresh token lifetime in days")

    # Redis configuration (four logical databases on the same host by default)
    # Redis configuration; separate logical databases for different purposes
    redis_cache_url: str = Field(..., env="REDIS_CACHE_URL", description="Redis connection URI for cache (DB 0)")
    redis_queue_url: str = Field(..., env="REDIS_QUEUE_URL", description="Redis connection URI for task queue (DB 1)")
    redis_session_url: str = Field(..., env="REDIS_SESSION_URL", description="Redis connection URI for sessions (DB 2)")
    redis_ratelimit_url: str = Field(..., env="REDIS_RATELIMIT_URL", description="Redis connection URI for rate limiting (DB 3)")

    # Application metadata
    project_name: str = Field("Cerebrum", env="PROJECT_NAME", description="Displayed project name")
    environment: str = Field("development", env="ENVIRONMENT", description="Application environment identifier")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        validate_assignment = True

    @validator("environment")
    def valid_environment(cls, v: str) -> str:
        allowed = {"development", "staging", "production"}
        if v not in allowed:
            raise ValueError(f"ENVIRONMENT must be one of {allowed}")
        return v


@lru_cache()
def get_settings() -> Settings:
    """Return a cached instance of the Settings.

    Using an LRU cache ensures that the Settings object is created once
    and reused throughout the application lifecycle.
    """
    return Settings()
