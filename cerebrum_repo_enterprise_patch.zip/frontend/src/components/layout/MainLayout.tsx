import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import Breadcrumb from '../ui/Breadcrumb';

// Combines the sidebar and topbar with the main content area. This
// component can be enhanced to provide responsive behaviour and
// accommodate additional UI shells specified in later phases.
export default function MainLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex flex-col flex-1">
        <TopBar onMenuClick={() => setSidebarOpen((prev) => !prev)} />
        <main className="flex-1 overflow-y-auto p-4 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
          {/* Breadcrumb navigation displayed above page content */}
          <Breadcrumb />
          <Outlet />
        </main>
      </div>
    </div>
  );
}
