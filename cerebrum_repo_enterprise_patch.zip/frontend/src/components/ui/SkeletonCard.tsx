import React from 'react';

export default function SkeletonCard() {
  return (
    <div className="animate-pulse bg-gray-200 dark:bg-gray-700 h-24 w-full rounded-md" />
  );
}