"""
RFI API endpoints.

Allows creation, listing and answering of RFIs. RFIs are questions
from subcontractors or team members that require clarification.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
import uuid

from ...db.session import SessionLocal
from ...models.rfi import RFI, RfiStatus

router = APIRouter(prefix="/rfis", tags=["rfis"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class RfiCreate(BaseModel):
    project_id: uuid.UUID
    tenant_id: uuid.UUID
    number: str = Field(..., example="RFI-001")
    question: str
    submitted_by: str
    due_date: str | None = None
    attachments: dict | None = None


class RfiRead(BaseModel):
    id: uuid.UUID
    project_id: uuid.UUID
    tenant_id: uuid.UUID
    number: str
    question: str
    answer: str | None
    status: RfiStatus
    submitted_by: str
    due_date: str | None
    attachments: dict | None

    class Config:
        orm_mode = True


class RfiAnswer(BaseModel):
    answer: str
    status: RfiStatus = Field(RfiStatus.answered)


@router.get("/", response_model=list[RfiRead])
def list_rfis(db: Session = Depends(get_db)) -> list[RfiRead]:
    rfis = db.query(RFI).all()
    return rfis


@router.post("/", response_model=RfiRead, status_code=status.HTTP_201_CREATED)
def create_rfi(rfi_in: RfiCreate, db: Session = Depends(get_db)) -> RfiRead:
    rfi = RFI(
        project_id=rfi_in.project_id,
        tenant_id=rfi_in.tenant_id,
        number=rfi_in.number,
        question=rfi_in.question,
        submitted_by=rfi_in.submitted_by,
        due_date=rfi_in.due_date,
        attachments=rfi_in.attachments,
        status=RfiStatus.open,
    )
    db.add(rfi)
    db.commit()
    db.refresh(rfi)
    return rfi


@router.get("/{rfi_id}", response_model=RfiRead)
def get_rfi(rfi_id: uuid.UUID, db: Session = Depends(get_db)) -> RfiRead:
    rfi = db.query(RFI).filter(RFI.id == rfi_id).first()
    if not rfi:
        raise HTTPException(status_code=404, detail="RFI not found")
    return rfi


@router.patch("/{rfi_id}", response_model=RfiRead)
def answer_rfi(rfi_id: uuid.UUID, answer_in: RfiAnswer, db: Session = Depends(get_db)) -> RfiRead:
    rfi = db.query(RFI).filter(RFI.id == rfi_id).first()
    if not rfi:
        raise HTTPException(status_code=404, detail="RFI not found")
    rfi.answer = answer_in.answer
    rfi.status = answer_in.status
    db.commit()
    db.refresh(rfi)
    return rfi