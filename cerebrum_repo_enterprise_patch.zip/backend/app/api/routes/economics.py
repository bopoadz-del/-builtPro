"""
API routes for basic economics and cost management.

This module exposes CRUD operations for budgets and change orders.
Currently the endpoints are minimal and use synchronous SQLAlchemy
sessions. In a production system, you would add authentication,
authorization, pagination, validation and error handling.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
import uuid

from ...db.session import SessionLocal
from ...models.economics import Budget, ChangeOrder


router = APIRouter(prefix="/economics", tags=["economics"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class BudgetCreate(BaseModel):
    project_id: uuid.UUID
    total_amount: float = Field(..., ge=0)
    currency: str = Field(..., min_length=3, max_length=3)
    contingency_percentage: float | None = Field(None, ge=0, le=100)


class BudgetRead(BaseModel):
    id: uuid.UUID
    project_id: uuid.UUID
    total_amount: float
    currency: str
    contingency_percentage: float | None
    is_final: bool

    class Config:
        orm_mode = True


@router.get("/budgets", response_model=list[BudgetRead])
def list_budgets(db: Session = Depends(get_db)) -> list[BudgetRead]:
    """List all budgets in the system.

    In a multi‑tenant deployment this should be filtered by tenant or
    project. Returns all budgets for demonstration purposes.
    """
    budgets = db.query(Budget).all()
    return budgets


@router.post("/budgets", response_model=BudgetRead)
def create_budget(budget_in: BudgetCreate, db: Session = Depends(get_db)) -> BudgetRead:
    """Create a new budget.

    A real implementation would include permission checks and more
    robust validation. This endpoint simply inserts a record.
    """
    new_budget = Budget(
        project_id=budget_in.project_id,
        total_amount=budget_in.total_amount,
        currency=budget_in.currency,
        contingency_percentage=budget_in.contingency_percentage,
        is_final=False,
    )
    db.add(new_budget)
    db.commit()
    db.refresh(new_budget)
    return new_budget