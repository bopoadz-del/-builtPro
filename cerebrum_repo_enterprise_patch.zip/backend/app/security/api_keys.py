"""
API Key management utilities.

Provides functions for creating, hashing and verifying API keys,
parsing scopes, and checking permissions. This is a simplified
example – real implementations should use a stronger hashing
algorithm (e.g. Argon2) and store keys securely. Additionally,
scopes should be validated against a registry of allowed
permissions.
"""

import secrets
import hashlib
from typing import List, Set


def generate_api_key(length: int = 32) -> str:
    """Generate a random API key.

    Returns a URL‑safe string of ``length`` bytes.
    """
    return secrets.token_urlsafe(length)


def hash_api_key(key: str) -> str:
    """Hash an API key using SHA‑256. Returns the hexadecimal digest."""
    return hashlib.sha256(key.encode('utf-8')).hexdigest()


def parse_scopes(scope_str: str) -> Set[str]:
    """Parse a comma‑separated scope string into a set of scopes."""
    return {scope.strip() for scope in scope_str.split(',') if scope.strip()}


def scopes_authorized(required: List[str], provided: str) -> bool:
    """Check if all required scopes are included in the provided scopes.

    Args:
        required: List of required scope strings.
        provided: Comma‑separated scope string stored on the API key.

    Returns:
        True if every required scope is present; False otherwise.
    """
    provided_set = parse_scopes(provided)
    return all(scope in provided_set for scope in required)