import React from 'react';

export default function EdgeDevices() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Edge Devices</h2>
      <p>Device grid and OTA deployment status will be shown here.</p>
    </div>
  );
}