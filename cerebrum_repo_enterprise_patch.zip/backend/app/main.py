"""FastAPI application factory.

This module instantiates the FastAPI app, registers routers, and sets
middleware such as CORS and logging. Additional startup and shutdown
events may be added here in future phases (e.g. to warm caches or
establish connections to external services).
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .core.config import get_settings
from .api.routes import api_router


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title=settings.project_name)

    # CORS configuration: allow only specific origins in production
    origins = ["*"] if settings.environment == "development" else []
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(api_router)

    @app.get("/health")
    async def health_check():
        return {"status": "ok"}

    @app.get("/health/deep")
    async def health_check_deep():
        """Perform a deep health probe.

        This endpoint performs basic checks against the database and
        Redis queue. In production you would also check external
        dependencies (e.g. third‑party APIs), disk space and memory.
        """
        from sqlalchemy import text
        from .core.database import engine
        status = {
            "database": False,
            "redis_queue": False,
        }
        # Check database by executing a trivial statement
        try:
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            status["database"] = True
        except Exception:
            status["database"] = False
        # Check Redis queue by pinging via Celery's broker
        try:
            # Celery broker uses Redis; send ping via Celery app
            from .tasks import celery_app
            celery_app.control.ping(timeout=1)
            status["redis_queue"] = True
        except Exception:
            status["redis_queue"] = False
        return status

    @app.get("/health/deep")
    async def deep_health_check():
        """Perform a deep health probe.

        Checks database connectivity and Redis availability. Future
        implementations can also check external APIs, disk space and
        other dependencies. Returns a dictionary of component statuses.
        """
        from .core.database import engine
        import redis

        db_ok = True
        try:
            with engine.connect() as conn:
                conn.execute("SELECT 1")
        except Exception:
            db_ok = False

        redis_ok = True
        try:
            r = redis.Redis.from_url(settings.redis_cache_url)
            r.ping()
        except Exception:
            redis_ok = False

        status = {
            "database": "ok" if db_ok else "fail",
            "redis": "ok" if redis_ok else "fail",
        }
        overall = all(val == "ok" for val in status.values())
        return {"status": "ok" if overall else "fail", **status}

    return app


app = create_app()
