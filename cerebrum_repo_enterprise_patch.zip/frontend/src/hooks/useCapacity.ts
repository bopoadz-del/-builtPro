import { useEffect } from 'react';
import { useSettings } from '../store/useSettings';

/**
 * Polls the capacity endpoint every 5 seconds and updates the capacity state.
 * Accepts a session token (for demonstration only). On unmount, aborts the
 * request and clears the interval.
 */
export function useCapacity(token: string | null) {
  const { setCapacity } = useSettings();
  useEffect(() => {
    if (!token) return;
    let cancelled = false;
    const controller = new AbortController();
    const fetchCapacity = async () => {
      try {
        const res = await fetch(`/sessions/${token}/capacity`, {
          signal: controller.signal,
        });
        const data = await res.json();
        if (!cancelled && typeof data.capacity === 'number') {
          setCapacity(data.capacity);
        }
      } catch {
        // Ignore fetch errors (e.g. network, aborted)
      }
    };
    fetchCapacity();
    const interval = setInterval(fetchCapacity, 5000);
    return () => {
      cancelled = true;
      controller.abort();
      clearInterval(interval);
    };
  }, [token, setCapacity]);
}