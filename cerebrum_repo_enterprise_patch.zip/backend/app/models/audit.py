"""Audit logging model capturing user actions."""

import uuid
import enum
from typing import Optional, Dict, Any

from sqlalchemy import Column, Enum, String, DateTime, ForeignKey, JSON
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from .base import Base


class AuditAction(str, enum.Enum):
    """Enumeration of auditable actions."""
    LOGIN = "LOGIN"
    LOGOUT = "LOGOUT"
    CREATE = "CREATE"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    READ = "READ"


class AuditLog(Base):
    """Persistent record of user activity.

    This model stores who did what and when on which resource. It is
    intentionally immutable and should be configured with external
    write‑once storage when scaling for compliance.
    """

    user_id = Column(UUID(as_uuid=True), ForeignKey("user.id"), nullable=False, index=True)
    action = Column(Enum(AuditAction), nullable=False)
    resource_type = Column(String, nullable=False)
    resource_id = Column(UUID(as_uuid=True), nullable=True)
    ip_address = Column(String, nullable=True)
    user_agent = Column(String, nullable=True)
    metadata = Column(JSON, nullable=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    user = relationship("User", back_populates="audits")


# Composite index to optimise queries by user_id and timestamp
from sqlalchemy import Index

Index(
    "ix_audit_user_created_at",
    AuditLog.user_id,
    AuditLog.timestamp,
)
