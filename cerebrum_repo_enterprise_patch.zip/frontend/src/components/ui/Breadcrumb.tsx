import React from 'react';
import { Link, useLocation } from 'react-router-dom';

/**
 * Breadcrumb navigation component. Builds a breadcrumb trail based on
 * the current pathname. Each segment maps to a human‑readable label.
 * When nested routes are added later, this component will adjust
 * automatically by splitting the pathname. If a segment does not
 * have a matching label, it is capitalized and used as is.
 */
export default function Breadcrumb() {
  const location = useLocation();
  const pathnames = location.pathname.split('/').filter(Boolean);

  // Map URL segments to display names. Extend this map as more
  // sections are added to the application. Any segments not found
  // here will be displayed capitalized.
  const nameMap: Record<string, string> = {
    '': 'Dashboard',
    dashboard: 'Dashboard',
    registry: 'Registry',
    learning: 'Learning',
    sandbox: 'Sandbox',
    audit: 'Audit',
    pipelines: 'Pipelines',
    settings: 'API Management',
    tasks: 'Tasks',
    'bim-viewer': 'BIM Viewer',
    'action-items': 'Action Items',
    documents: 'Documents',
    chat: 'Chat',
    admin: 'Admin Panel',
    economics: 'Economics',
    'ml-tinker': 'ML Tinker',
    'edge-devices': 'Edge Devices',
    'field-data': 'Field Data',
    vdc: 'VDC',
    quality: 'Quality',
    subcontractor: 'Subcontractor',
  };

  // Build breadcrumb items. Always include the first root item.
  const crumbs = pathnames.length > 0 ? [''].concat(pathnames) : [''];

  return (
    <nav className="text-sm text-gray-500 dark:text-gray-400 mb-4" aria-label="Breadcrumb">
      <ol className="list-reset flex flex-wrap items-center space-x-2">
        {crumbs.map((segment, index) => {
          const to = '/' + crumbs.slice(1, index + 1).join('/');
          const label = nameMap[segment] || segment.replace(/-/g, ' ').replace(/^\w/, (c) => c.toUpperCase());
          const isLast = index === crumbs.length - 1;
          return (
            <li key={to + index} className="flex items-center">
              {index > 0 && <span className="mx-1">/</span>}
              {isLast ? (
                <span className="text-gray-700 dark:text-gray-200 font-medium truncate">{label}</span>
              ) : (
                <Link to={to || '/'} className="hover:underline truncate">
                  {label}
                </Link>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}