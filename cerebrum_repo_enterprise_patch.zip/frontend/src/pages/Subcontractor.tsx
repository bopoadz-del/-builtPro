import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from '../lib/api';
import { toast } from 'react-hot-toast';

interface Bid {
  id: string;
  project_id: string;
  tenant_id: string;
  subcontractor_name: string;
  items?: Record<string, any> | null;
  total_amount: number;
  status: string;
}

interface Rfi {
  id: string;
  project_id: string;
  tenant_id: string;
  number: string;
  question: string;
  answer?: string | null;
  status: string;
  submitted_by: string;
}

export default function Subcontractor() {
  const queryClient = useQueryClient();
  // State for new bid form
  const [projectId, setProjectId] = useState('');
  const [tenantId, setTenantId] = useState('');
  const [subcontractorName, setSubcontractorName] = useState('');
  const [totalAmount, setTotalAmount] = useState('');

  const { data: bids, isLoading: loadingBids } = useQuery<Bid[]>({
    queryKey: ['bids'],
    queryFn: async () => {
      const res = await axios.get('/bids');
      return res.data;
    },
  });

  const createBidMutation = useMutation({
    mutationFn: async () => {
      const res = await axios.post('/bids', {
        project_id: projectId,
        tenant_id: tenantId,
        subcontractor_name: subcontractorName,
        items: null,
        total_amount: parseFloat(totalAmount),
      });
      return res.data;
    },
    onSuccess: () => {
      toast.success('Bid submitted');
      queryClient.invalidateQueries({ queryKey: ['bids'] });
      setProjectId('');
      setTenantId('');
      setSubcontractorName('');
      setTotalAmount('');
    },
    onError: () => {
      toast.error('Failed to submit bid');
    },
  });

  // RFI state
  const [rfiProjectId, setRfiProjectId] = useState('');
  const [rfiTenantId, setRfiTenantId] = useState('');
  const [rfiNumber, setRfiNumber] = useState('');
  const [rfiQuestion, setRfiQuestion] = useState('');
  const [rfiSubmittedBy, setRfiSubmittedBy] = useState('');

  const { data: rfis, isLoading: loadingRfis } = useQuery<Rfi[]>({
    queryKey: ['rfis'],
    queryFn: async () => {
      const res = await axios.get('/rfis');
      return res.data;
    },
  });

  const createRfiMutation = useMutation({
    mutationFn: async () => {
      const res = await axios.post('/rfis', {
        project_id: rfiProjectId,
        tenant_id: rfiTenantId,
        number: rfiNumber,
        question: rfiQuestion,
        submitted_by: rfiSubmittedBy,
      });
      return res.data;
    },
    onSuccess: () => {
      toast.success('RFI submitted');
      queryClient.invalidateQueries({ queryKey: ['rfis'] });
      setRfiProjectId('');
      setRfiTenantId('');
      setRfiNumber('');
      setRfiQuestion('');
      setRfiSubmittedBy('');
    },
    onError: () => {
      toast.error('Failed to submit RFI');
    },
  });

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Subcontractor Portal</h2>
      <p className="mb-6">Submit bids and RFIs for your trade packages.</p>
      {/* Bid submission form */}
      <div className="mb-8 p-4 bg-white dark:bg-gray-800 rounded shadow">
        <h3 className="font-semibold mb-2">Submit Bid</h3>
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 mb-4">
          <input
            type="text"
            placeholder="Project ID"
            value={projectId}
            onChange={(e) => setProjectId(e.target.value)}
            className="border p-2 rounded"
          />
          <input
            type="text"
            placeholder="Tenant ID"
            value={tenantId}
            onChange={(e) => setTenantId(e.target.value)}
            className="border p-2 rounded"
          />
          <input
            type="text"
            placeholder="Subcontractor Name"
            value={subcontractorName}
            onChange={(e) => setSubcontractorName(e.target.value)}
            className="border p-2 rounded"
          />
          <input
            type="number"
            placeholder="Total Amount"
            value={totalAmount}
            onChange={(e) => setTotalAmount(e.target.value)}
            className="border p-2 rounded"
          />
        </div>
        <button
          onClick={() => createBidMutation.mutate()}
          disabled={createBidMutation.isLoading || !projectId || !tenantId || !subcontractorName || !totalAmount}
          className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded disabled:opacity-50"
        >
          {createBidMutation.isLoading ? 'Submitting...' : 'Submit Bid'}
        </button>
      </div>
      {/* Bid list */}
      <div className="mb-8 bg-white dark:bg-gray-800 rounded shadow p-4">
        <h3 className="font-semibold mb-2">Your Bids</h3>
        {loadingBids ? (
          <p>Loading bids...</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100 dark:bg-gray-700">
                  <th className="px-2 py-1 text-left">ID</th>
                  <th className="px-2 py-1 text-left">Project</th>
                  <th className="px-2 py-1 text-left">Amount</th>
                  <th className="px-2 py-1 text-left">Status</th>
                </tr>
              </thead>
              <tbody>
                {bids && bids.length > 0 ? (
                  bids.map((b) => (
                    <tr key={b.id} className="border-t">
                      <td className="px-2 py-1 truncate" title={b.id}>{b.id}</td>
                      <td className="px-2 py-1 truncate" title={b.project_id}>{b.project_id}</td>
                      <td className="px-2 py-1">${b.total_amount.toFixed(2)}</td>
                      <td className="px-2 py-1 capitalize">{b.status.replace('_', ' ')}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="px-2 py-2 text-center">No bids found.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
      {/* RFI submission form */}
      <div className="mb-8 p-4 bg-white dark:bg-gray-800 rounded shadow">
        <h3 className="font-semibold mb-2">Submit RFI</h3>
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 mb-4">
          <input
            type="text"
            placeholder="Project ID"
            value={rfiProjectId}
            onChange={(e) => setRfiProjectId(e.target.value)}
            className="border p-2 rounded"
          />
          <input
            type="text"
            placeholder="Tenant ID"
            value={rfiTenantId}
            onChange={(e) => setRfiTenantId(e.target.value)}
            className="border p-2 rounded"
          />
          <input
            type="text"
            placeholder="RFI Number"
            value={rfiNumber}
            onChange={(e) => setRfiNumber(e.target.value)}
            className="border p-2 rounded"
          />
          <input
            type="text"
            placeholder="Question"
            value={rfiQuestion}
            onChange={(e) => setRfiQuestion(e.target.value)}
            className="border p-2 rounded"
          />
          <input
            type="text"
            placeholder="Submitted By"
            value={rfiSubmittedBy}
            onChange={(e) => setRfiSubmittedBy(e.target.value)}
            className="border p-2 rounded"
          />
        </div>
        <button
          onClick={() => createRfiMutation.mutate()}
          disabled={createRfiMutation.isLoading || !rfiProjectId || !rfiTenantId || !rfiNumber || !rfiQuestion || !rfiSubmittedBy}
          className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded disabled:opacity-50"
        >
          {createRfiMutation.isLoading ? 'Submitting...' : 'Submit RFI'}
        </button>
      </div>
      {/* RFI list */}
      <div className="bg-white dark:bg-gray-800 rounded shadow p-4">
        <h3 className="font-semibold mb-2">Your RFIs</h3>
        {loadingRfis ? (
          <p>Loading RFIs...</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gray-100 dark:bg-gray-700">
                  <th className="px-2 py-1 text-left">ID</th>
                  <th className="px-2 py-1 text-left">Number</th>
                  <th className="px-2 py-1 text-left">Question</th>
                  <th className="px-2 py-1 text-left">Status</th>
                </tr>
              </thead>
              <tbody>
                {rfis && rfis.length > 0 ? (
                  rfis.map((r) => (
                    <tr key={r.id} className="border-t">
                      <td className="px-2 py-1 truncate" title={r.id}>{r.id}</td>
                      <td className="px-2 py-1">{r.number}</td>
                      <td className="px-2 py-1">{r.question}</td>
                      <td className="px-2 py-1 capitalize">{r.status.replace('_', ' ')}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="px-2 py-2 text-center">No RFIs found.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}