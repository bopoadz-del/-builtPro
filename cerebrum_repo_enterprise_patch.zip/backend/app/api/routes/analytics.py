"""Analytics API routes.

These endpoints expose the analytics and data warehouse capabilities
of Cerebrum. They allow triggering ETL processes and retrieving
portfolio summaries. As the analytics engine matures additional
endpoints can be added for predictive models, charts, and custom
reports.
"""

from fastapi import APIRouter, status

from ...analytics import warehouse


router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.post("/etl", status_code=status.HTTP_202_ACCEPTED)
def run_etl() -> dict[str, str]:
    """Trigger a warehouse ETL process.

    Returns a status message indicating that the ETL job has been
    started. In a real system this endpoint might dispatch a task to
    Celery or another background job runner and return a job ID.
    """
    return warehouse.run_etl()


@router.get("/portfolio", response_model=dict)
def get_portfolio_summary() -> dict[str, object]:
    """Return a summary of project portfolio metrics."""
    return warehouse.get_portfolio_summary()