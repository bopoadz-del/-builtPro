"""Tenant model for multi‑tenancy.

Tenants isolate data across customers. Each tenant has a unique ID
and a name. Additional fields can be added to support subscription
levels or branding information.
"""

from sqlalchemy import Column, String, Boolean, DateTime
from sqlalchemy.dialects.postgresql import UUID

from .base import Base


class Tenant(Base):
    """Represents a customer tenant.

    Tenants isolate data across customers. Each tenant can have a
    custom subdomain (e.g. ``company.cerebrum.ai``), branding such as a
    logo URL, a subscription plan, and trial expiration. Additional
    fields can be added for billing or feature flags.
    """

    # Tenant name (e.g. Company Inc.) – must be unique
    name = Column(String, unique=True, nullable=False)
    # Subdomain for tenant access (e.g. company) – must be unique
    subdomain = Column(String, unique=True, nullable=False)
    # URL to tenant logo stored in S3 or other storage
    logo_url = Column(String, nullable=True)
    # Subscription plan identifier (e.g. free, pro, enterprise)
    plan = Column(String, nullable=False, default="free")
    # Trial end date; if null then no trial or trial expired
    trial_ends_at = Column(DateTime(timezone=True), nullable=True)
    # Whether the tenant is currently active; deactivated tenants cannot log in
    is_active = Column(Boolean, nullable=False, default=True)
