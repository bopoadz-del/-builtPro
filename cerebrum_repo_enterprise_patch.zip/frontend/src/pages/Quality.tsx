import React from 'react';

export default function Quality() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Quality</h2>
      <p>Inspection checklists and NCR reporting will be added here.</p>
    </div>
  );
}