"""
RFI (Request for Information) model.

Represents a formal question submitted by a subcontractor or project
team member that requires clarification from the design team or
general contractor. RFIs have a status to track the resolution.
"""

import uuid
from sqlalchemy import Column, String, Enum, DateTime, JSON
from sqlalchemy.dialects.postgresql import UUID

from .base import Base


class RfiStatus(str, Enum):  # type: ignore[misc]
    open = "open"
    answered = "answered"
    closed = "closed"


class RFI(Base):
    __tablename__ = "rfi"

    project_id = Column(UUID(as_uuid=True), nullable=False)
    tenant_id = Column(UUID(as_uuid=True), nullable=False)
    number = Column(String, nullable=False)
    question = Column(String, nullable=False)
    answer = Column(String, nullable=True)
    status = Column(Enum(RfiStatus), nullable=False, default=RfiStatus.open)
    submitted_by = Column(String, nullable=False)  # user email or ID
    due_date = Column(DateTime(timezone=True), nullable=True)
    attachments = Column(JSON, nullable=True)