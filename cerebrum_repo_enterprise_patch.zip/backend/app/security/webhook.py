"""
Webhook signing and verification.

This module provides helpers to sign outbound webhooks with an HMAC
signature and verify incoming webhooks. A secret should be shared
between the sender and receiver. For replay attack prevention,
include a timestamp and validate its freshness.
"""

import hmac
import hashlib
import time
from typing import Tuple


def sign_payload(payload: bytes, secret: bytes) -> Tuple[str, str]:
    """Compute a signature for the given payload.

    Returns a tuple of (timestamp, signature). The signature is an
    HMAC‑SHA256 of timestamp + '.' + payload.
    """
    timestamp = str(int(time.time()))
    message = timestamp.encode('utf-8') + b'.' + payload
    signature = hmac.new(secret, message, hashlib.sha256).hexdigest()
    return timestamp, signature


def verify_signature(payload: bytes, secret: bytes, timestamp: str, signature: str, tolerance: int = 300) -> bool:
    """Verify a webhook signature and timestamp.

    Args:
        payload: The request body bytes.
        secret: Shared secret used to compute the signature.
        timestamp: Timestamp sent with the request.
        signature: Hex digest of the HMAC signature.
        tolerance: Time in seconds before the timestamp is considered expired.

    Returns:
        True if the signature matches and the timestamp is within the
        tolerance; False otherwise.
    """
    # Verify timestamp freshness
    current = int(time.time())
    try:
        ts_int = int(timestamp)
    except ValueError:
        return False
    if abs(current - ts_int) > tolerance:
        return False
    # Compute expected signature
    message = timestamp.encode('utf-8') + b'.' + payload
    expected_sig = hmac.new(secret, message, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected_sig, signature)