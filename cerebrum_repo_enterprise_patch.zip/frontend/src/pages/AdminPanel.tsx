import React from 'react';

export default function AdminPanel() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Admin Panel</h2>
      <p>User management and system settings will be available here.</p>
    </div>
  );
}