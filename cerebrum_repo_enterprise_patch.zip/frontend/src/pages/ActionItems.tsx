import React from 'react';

export default function ActionItems() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Action Items</h2>
      <p>A Kanban board for tasks will be built here.</p>
    </div>
  );
}