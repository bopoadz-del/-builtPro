"""Script to back up the PostgreSQL database to a file.

This is a simplified example that runs pg_dump locally; in
production you might upload the dump to object storage and encrypt
it. The script is intended to be invoked via cron or a scheduler.
"""

import os
import subprocess
from datetime import datetime


def backup_database():
    db_name = os.environ.get("POSTGRES_DB", "cerebrum")
    user = os.environ.get("POSTGRES_USER", "cerebrum")
    password = os.environ.get("POSTGRES_PASSWORD", "cerebrum")
    host = os.environ.get("DB_HOST", "localhost")
    port = os.environ.get("DB_PORT", "5432")
    ts = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    filename = f"backup_{db_name}_{ts}.sql"
    command = [
        "pg_dump",
        f"--dbname=postgresql://{user}:{password}@{host}:{port}/{db_name}",
        "--format=plain",
        f"--file={filename}",
    ]
    subprocess.run(command, check=True)
    print(f"Backup completed: {filename}")


if __name__ == "__main__":
    backup_database()
