"""
Row Level Security (RLS) utilities.

This module provides helper functions to enable and manage PostgreSQL
row level security policies for multi‑tenant data isolation. The
policies use the ``app.current_tenant`` setting to scope queries
automatically. Actual policy creation should be executed during
deployment or via migration scripts. These helpers can be used at
runtime to set the current tenant on a session.
"""

from sqlalchemy.engine import Connection
from sqlalchemy.orm import Session


def set_current_tenant(session: Session, tenant_id: str) -> None:
    """Set the current tenant for a session by using SET LOCAL.

    Args:
        session: SQLAlchemy session whose connection will be used.
        tenant_id: The UUID of the tenant as a string.

    Usage:
        set_current_tenant(db_session, str(tenant_id))

    After calling this, any RLS policies referencing
    current_setting('app.current_tenant') will evaluate against
    ``tenant_id``. This requires that the PostgreSQL configuration
    parameter ``app.current_tenant`` be declared as a
    ``PG_CATALOG.lc_ctype`` variable in the DB configuration.
    """
    conn: Connection = session.connection()
    # Use SET LOCAL so the setting applies only for the current transaction
    conn.execute("SET LOCAL app.current_tenant = %s", (tenant_id,))


def enable_rls(conn: Connection, table_name: str) -> None:
    """Enable row level security on a given table.

    Args:
        conn: SQLAlchemy connection or engine to execute raw SQL.
        table_name: The name of the table on which to enable RLS.

    This function issues ``ALTER TABLE ... ENABLE ROW LEVEL SECURITY``.
    In production, consider using migrations to manage RLS.
    """
    conn.execute(f"ALTER TABLE {table_name} ENABLE ROW LEVEL SECURITY;")


def create_tenant_policy(conn: Connection, table_name: str, tenant_column: str = "tenant_id") -> None:
    """Create a tenant isolation policy for a table.

    Args:
        conn: SQLAlchemy connection.
        table_name: Name of the table.
        tenant_column: Name of the column containing tenant IDs.

    This policy restricts SELECT, UPDATE and DELETE operations to rows
    where ``tenant_column = current_setting('app.current_tenant')``. It
    trusts that the application sets the current tenant accordingly.
    """
    policy_name = f"{table_name}_tenant_isolation"
    sql = (
        f"CREATE POLICY {policy_name} ON {table_name} "
        f"USING ({tenant_column} = current_setting('app.current_tenant')::uuid);"
    )
    conn.execute(sql)