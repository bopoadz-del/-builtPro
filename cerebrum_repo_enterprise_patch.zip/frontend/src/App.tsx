import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import MainLayout from './components/layout/MainLayout';
import ErrorBoundary from './components/ErrorBoundary';

// Page components
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Registry from './pages/Registry';
import Learning from './pages/Learning';
import Sandbox from './pages/Sandbox';
import Audit from './pages/Audit';
import Pipelines from './pages/Pipelines';
import Settings from './pages/Settings';
import Tasks from './pages/Tasks';
import BIMViewer from './pages/BIMViewer';
import ActionItems from './pages/ActionItems';
import Documents from './pages/Documents';
import Chat from './pages/Chat';
import AdminPanel from './pages/AdminPanel';
import Economics from './pages/Economics';
import MLTinker from './pages/MLTinker';
import EdgeDevices from './pages/EdgeDevices';
import FieldData from './pages/FieldData';
import VDC from './pages/VDC';
import Quality from './pages/Quality';
import Subcontractor from './pages/Subcontractor';
import Analytics from './pages/Analytics';

/**
 * Core application component that defines all routes. Each route is wrapped
 * in an ErrorBoundary to ensure isolated error handling. A Toaster is
 * included at the top level for toast notifications across the app.
 */
export default function App() {
  return (
    <>
      {/* Toast notifications container */}
      <Toaster position="top-right" />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<MainLayout />}>        
          <Route
            index
            element={
              <ErrorBoundary>
                <Dashboard />
              </ErrorBoundary>
            }
          />
          <Route
            path="registry"
            element={
              <ErrorBoundary>
                <Registry />
              </ErrorBoundary>
            }
          />
          <Route
            path="learning"
            element={
              <ErrorBoundary>
                <Learning />
              </ErrorBoundary>
            }
          />
          <Route
            path="sandbox"
            element={
              <ErrorBoundary>
                <Sandbox />
              </ErrorBoundary>
            }
          />
          <Route
            path="audit"
            element={
              <ErrorBoundary>
                <Audit />
              </ErrorBoundary>
            }
          />
          <Route
            path="pipelines"
            element={
              <ErrorBoundary>
                <Pipelines />
              </ErrorBoundary>
            }
          />
          <Route
            path="settings"
            element={
              <ErrorBoundary>
                <Settings />
              </ErrorBoundary>
            }
          />
          <Route
            path="tasks"
            element={
              <ErrorBoundary>
                <Tasks />
              </ErrorBoundary>
            }
          />
          <Route
            path="bim-viewer"
            element={
              <ErrorBoundary>
                <BIMViewer />
              </ErrorBoundary>
            }
          />
          <Route
            path="action-items"
            element={
              <ErrorBoundary>
                <ActionItems />
              </ErrorBoundary>
            }
          />
          <Route
            path="documents"
            element={
              <ErrorBoundary>
                <Documents />
              </ErrorBoundary>
            }
          />
          <Route
            path="chat"
            element={
              <ErrorBoundary>
                <Chat />
              </ErrorBoundary>
            }
          />
          <Route
            path="admin"
            element={
              <ErrorBoundary>
                <AdminPanel />
              </ErrorBoundary>
            }
          />
          <Route
            path="economics"
            element={
              <ErrorBoundary>
                <Economics />
              </ErrorBoundary>
            }
          />
          <Route
            path="ml-tinker"
            element={
              <ErrorBoundary>
                <MLTinker />
              </ErrorBoundary>
            }
          />
          <Route
            path="edge-devices"
            element={
              <ErrorBoundary>
                <EdgeDevices />
              </ErrorBoundary>
            }
          />
          <Route
            path="field-data"
            element={
              <ErrorBoundary>
                <FieldData />
              </ErrorBoundary>
            }
          />
          <Route
            path="vdc"
            element={
              <ErrorBoundary>
                <VDC />
              </ErrorBoundary>
            }
          />
          <Route
            path="quality"
            element={
              <ErrorBoundary>
                <Quality />
              </ErrorBoundary>
            }
          />
          <Route
            path="subcontractor"
            element={
              <ErrorBoundary>
                <Subcontractor />
              </ErrorBoundary>
            }
          />
          <Route
            path="analytics"
            element={
              <ErrorBoundary>
                <Analytics />
              </ErrorBoundary>
            }
          />
        </Route>
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </>
  );
}
