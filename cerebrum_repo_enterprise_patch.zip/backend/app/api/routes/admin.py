"""Admin endpoints for managing users and roles."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ...models.user import User, UserRole
from ...core.database import get_db

router = APIRouter()


@router.get("/users")
def list_users(skip: int = 0, limit: int = 50, db: Session = Depends(get_db)):
    """Return a paginated list of users."""
    users = db.query(User).offset(skip).limit(limit).all()
    return [
        {
            "id": str(u.id),
            "email": u.email,
            "role": u.role.value,
            "is_active": u.is_active,
        }
        for u in users
    ]


@router.patch("/users/{user_id}/role")
def update_role(user_id: str, role: UserRole, db: Session = Depends(get_db)):
    """Update a user's role."""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.role = role
    db.commit()
    db.refresh(user)
    return {"message": "Role updated", "user_id": user_id, "role": role.value}
